import os
import time
import requests
import urllib3
from flask import Flask, request, jsonify
from danger_ffjwt import guest_to_jwt
from Crypto.Cipher import AES

# ------------------------------
# Suppress InsecureRequestWarning
# ------------------------------
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ------------------------------
# Configuration
# ------------------------------
UID = os.environ.get("FF_UID", "4417073646")
PASSWORD = os.environ.get("FF_PASSWORD", "DANGERR-LS6WXk-IDS-BY-DANGER_FF_LIKE-IptIfx-pYB8zP")
OB_VERSION = "OB52"
CLIENT_VERSION = "1.120.1"
CACHE_DURATION = 7 * 3600  # 7 hours
DEV_TELEGRAM = "t.me/danger_ff_like"

# AES config from maker.py
AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

app = Flask(__name__)

# In-memory cache: { (uid, password): (token, expiry) }
token_cache = {}

# ------------------------------
# Protobuf helpers
# ------------------------------
def encode_varint(value: int) -> bytes:
    out = []
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            break
    return bytes(out)

def build_checkdirtywords_payload(name: str, field2: int = 1) -> bytes:
    name_bytes = name.encode('utf-8')
    payload = b'\x0a' + encode_varint(len(name_bytes)) + name_bytes  # field 1 (string)
    payload += b'\x10' + encode_varint(field2)                       # field 2 (int)
    return payload

def encrypt_packet(plaintext: bytes) -> bytes:
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    pad_len = 16 - (len(plaintext) % 16)
    plaintext += bytes([pad_len]) * pad_len
    return cipher.encrypt(plaintext)

# ------------------------------
# JWT token management with cache
# ------------------------------
def get_jwt_token():
    global token_cache
    key = (UID, PASSWORD)
    now = time.time()

    # Check cache
    if key in token_cache:
        token, expiry = token_cache[key]
        if now < expiry:
            return token

    # Generate new token
    try:
        jwt_data = guest_to_jwt(UID, PASSWORD,
                                ob_version=OB_VERSION,
                                client_version=CLIENT_VERSION)
        token = jwt_data.get("jwt_token")
        if not token:
            raise Exception("No jwt_token in response")
        token_cache[key] = (token, now + CACHE_DURATION)
        return token
    except Exception as e:
        raise Exception(f"Token generation failed: {e}")

# ------------------------------
# Helper to format response
# ------------------------------
def format_ff_response(resp: requests.Response, nickname: str):
    """Convert FreeFire response to user-friendly JSON with developer credit."""
    content = resp.content
    status_code = resp.status_code

    # Default response structure
    result = {
        "developer": DEV_TELEGRAM,
        "nickname": nickname
    }

    # Try to decode as UTF-8 text
    try:
        text = content.decode('utf-8').strip()
        # If it's plain text
        if status_code == 200:
            # Check for dirty word indicators
            if "DIRTY_WORD" in text or "dirty" in text.lower():
                result["status"] = "dirty"
                result["message"] = f"Nickname contains dirty words: {text}"
            else:
                result["status"] = "clean"
                result["message"] = "Nickname is fully safe (no dirty words)"
        else:
            # Non-200 response
            result["status"] = "error"
            result["message"] = text
            # Include raw_hex only for errors
            result["raw_hex"] = content.hex()
    except UnicodeDecodeError:
        # Binary response
        if status_code == 200:
            result["status"] = "unknown"
            result["message"] = "Received binary response from server"
        else:
            result["status"] = "error"
            result["message"] = "Binary error response"
        # Include raw_hex for binary responses (both success and error)
        result["raw_hex"] = content.hex()

    return result

# ------------------------------
# Flask routes
# ------------------------------
@app.route('/')
def home():
    return jsonify({
        "name": "FreeFire Dirty Word Checker API",
        "endpoint": "/checkdirty?name=YOUR_NAME",
        "usage": "Returns whether the name contains dirty words.",
        "developer": DEV_TELEGRAM
    })

@app.route('/checkdirty', methods=['GET'])
def check_dirty():
    name = request.args.get('name')
    if not name:
        return jsonify({
            "error": "Missing 'name' parameter",
            "developer": DEV_TELEGRAM
        }), 400

    try:
        # 1. Get cached/valid JWT
        jwt_token = get_jwt_token()

        # 2. Build and encrypt payload
        plain = build_checkdirtywords_payload(name)
        encrypted = encrypt_packet(plain)

        # 3. Prepare request to Free Fire
        headers = {
            "Host": "client.ind.freefiremobile.com",
            "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
            "Accept": "*/*",
            "Accept-Encoding": "deflate, gzip",
            "Authorization": f"Bearer {jwt_token}",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB52",
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Unity-Version": "2022.3.47f1",
        }

        # 4. Send POST (verify=False to avoid cert errors)
        resp = requests.post(
            "https://client.ind.freefiremobile.com/CheckDirtyWords",
            headers=headers,
            data=encrypted,
            verify=False,
            timeout=10
        )

        # 5. Format and return the response
        result = format_ff_response(resp, name)
        return jsonify(result), resp.status_code

    except Exception as e:
        return jsonify({
            "error": str(e),
            "developer": DEV_TELEGRAM
        }), 500

# ------------------------------
# For local development
# ------------------------------
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)