#CREDIT:- @vaibhavff570
#JOIN :- @vaibhavff570
#GC :- @vaibhavff570
#DON'T CHANGE MY CREDIS OR FUCK YOUR MOTHER

import hmac
import hashlib
import requests
import string
import random
import json
import codecs
import time
import os
import sys
import base64
import signal
import threading
import re
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from colorama import Fore, Style, init
import urllib3

# ========== ACTIVATOR DEPENDENCIES ==========
import logging
import glob
from concurrent.futures import ThreadPoolExecutor, as_completed

# Try to import protobuf module – required for activation
try:
    import MajorLoginRes_pb2
except ImportError:
    print("⚠️  MajorLoginRes_pb2 not found. Activation will fail.")
    MajorLoginRes_pb2 = None

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ========== PREMIUM NEON COLOR SYSTEM ==========
init(autoreset=False)

C = Fore.CYAN
M = Fore.MAGENTA
W = Fore.WHITE
R = Style.RESET_ALL
B = Style.BRIGHT

BDR        = Fore.CYAN + Style.DIM
TIT        = Fore.LIGHTCYAN_EX + Style.BRIGHT
LBL_BLUE   = Fore.LIGHTBLUE_EX + Style.NORMAL
LBL_CYAN   = Fore.LIGHTCYAN_EX + Style.NORMAL
VAL        = Fore.LIGHTMAGENTA_EX + Style.BRIGHT
HIGHLIGHT  = Fore.WHITE + Style.BRIGHT
SYM_CYAN   = Fore.LIGHTCYAN_EX + Style.BRIGHT
SYM_YELLOW = Fore.LIGHTYELLOW_EX + Style.BRIGHT
SYM_RED    = Fore.LIGHTRED_EX + Style.BRIGHT
ICON_YELLOW= Fore.LIGHTYELLOW_EX

# ========== HIDDEN CONSTANTS (KEEP ORIGINAL) ==========
_H1 = "VkVSV1NGRlZVVlZFVk5WQQ=="
_H2 = "UkdWeFVGRkZWRVZGVlJRVkE9PQ=="
_H3 = "VkZSU1RVRkZWREVGRlJXUUE9PQ=="
_XOR = [0x42, 0x59, 0x5F, 0x42, 0x49, 0x47, 0x42, 0x55, 0x4C, 0x4C, 0x5F]

def _get_hidden():
    return "VAIBHAV"

_HIDDEN = _get_hidden()

# =============================================================================
# DEVICE ROTATION CONFIGURATION - ADDED FROM MAIN.PY
# =============================================================================

DEVICE_POOL = [
    # Samsung Devices
    {"model": "SM-G973F", "brand": "Samsung", "device": "beyond1", "android": "12", "sdk": "31", "manufacturer": "samsung", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G973F Build/SP1A.210812.016)"},
    {"model": "SM-G998B", "brand": "Samsung", "device": "p3s", "android": "13", "sdk": "33", "manufacturer": "samsung", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; SM-G998B Build/TP1A.220624.014)"},
    {"model": "SM-G991B", "brand": "Samsung", "device": "o1s", "android": "13", "sdk": "33", "manufacturer": "samsung", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; SM-G991B Build/TP1A.220624.014)"},
    {"model": "SM-A536E", "brand": "Samsung", "device": "a53x", "android": "13", "sdk": "33", "manufacturer": "samsung", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; SM-A536E Build/TP1A.220624.014)"},
    {"model": "SM-M526B", "brand": "Samsung", "device": "m52", "android": "12", "sdk": "31", "manufacturer": "samsung", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-M526B Build/SP1A.210812.016)"},

    # Xiaomi Devices
    {"model": "M2101K7AG", "brand": "Xiaomi", "device": "courbet", "android": "12", "sdk": "31", "manufacturer": "Xiaomi", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; M2101K7AG Build/SKQ1.210908.001)"},
    {"model": "M2012K11AG", "brand": "Xiaomi", "device": "alioth", "android": "13", "sdk": "33", "manufacturer": "Xiaomi", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; M2012K11AG Build/TKQ1.220829.002)"},
    {"model": "22041216I", "brand": "Xiaomi", "device": "xaga", "android": "12", "sdk": "31", "manufacturer": "Xiaomi", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; 22041216I Build/SP1A.210812.016)"},
    {"model": "2201117TG", "brand": "Xiaomi", "device": "spes", "android": "13", "sdk": "33", "manufacturer": "Xiaomi", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; 2201117TG Build/TKQ1.221114.001)"},

    # OnePlus Devices
    {"model": "LE2121", "brand": "OnePlus", "device": "oneplus9pro", "android": "13", "sdk": "33", "manufacturer": "OnePlus", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; LE2121 Build/TP1A.220905.001)"},
    {"model": "KB2001", "brand": "OnePlus", "device": "oneplus8t", "android": "12", "sdk": "31", "manufacturer": "OnePlus", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; KB2001 Build/SKQ1.210216.001)"},
    {"model": "IN2011", "brand": "OnePlus", "device": "OnePlus8", "android": "11", "sdk": "30", "manufacturer": "OnePlus", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 11; IN2011 Build/RP1A.201005.001)"},

    # Vivo Devices
    {"model": "V2111", "brand": "vivo", "device": "2111", "android": "12", "sdk": "31", "manufacturer": "vivo", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; V2111 Build/SP1A.210812.003)"},
    {"model": "V2109", "brand": "vivo", "device": "2109", "android": "11", "sdk": "30", "manufacturer": "vivo", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 11; V2109 Build/RP1A.200720.012)"},
    {"model": "V2230", "brand": "vivo", "device": "2230", "android": "13", "sdk": "33", "manufacturer": "vivo", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; V2230 Build/TP1A.220624.014)"},

    # Oppo Devices
    {"model": "CPH2467", "brand": "OPPO", "device": "OP56F3", "android": "13", "sdk": "33", "manufacturer": "OPPO", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; CPH2467 Build/TP1A.220905.001)"},
    {"model": "CPH2387", "brand": "OPPO", "device": "OP557F", "android": "12", "sdk": "31", "manufacturer": "OPPO", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; CPH2387 Build/SP1A.210812.016)"},
    {"model": "CPH2209", "brand": "OPPO", "device": "OP4F2F", "android": "11", "sdk": "30", "manufacturer": "OPPO", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 11; CPH2209 Build/RP1A.200720.011)"},

    # Realme Devices
    {"model": "RMX3562", "brand": "realme", "device": "RE54E4L1", "android": "13", "sdk": "33", "manufacturer": "realme", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 13; RMX3562 Build/TP1A.220905.001)"},
    {"model": "RMX3393", "brand": "realme", "device": "RE54B6L1", "android": "12", "sdk": "31", "manufacturer": "realme", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; RMX3393 Build/SP1A.210812.016)"},
    {"model": "RMX3241", "brand": "realme", "device": "RE513CL1", "android": "11", "sdk": "30", "manufacturer": "realme", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 11; RMX3241 Build/RP1A.200720.011)"},

    # ASUS Devices
    {"model": "ASUS_I005DA", "brand": "asus", "device": "ASUS_I005_1", "android": "9", "sdk": "28", "manufacturer": "asus", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)"},
    {"model": "ASUS_Z01QD", "brand": "asus", "device": "ASUS_Z01QD_1", "android": "12", "sdk": "31", "manufacturer": "asus", "user_agent": "Dalvik/2.1.0 (Linux; U; Android 12; ASUS_Z01QD Build/SKQ1.210216.001)"},
]

current_device = None
last_device_rotation = 0
DEVICE_ROTATION_INTERVAL = 10  # Rotate device every 10 accounts

def get_random_device():
    """Get a random device from the pool"""
    return random.choice(DEVICE_POOL)

def rotate_device():
    """Rotate to a new random device"""
    global current_device
    current_device = get_random_device()
    return current_device

def get_current_device():
    """Get current device or rotate if not set"""
    global current_device
    if current_device is None:
        current_device = get_random_device()
    return current_device

def should_rotate_device(counter):
    """Check if device should be rotated based on counter"""
    return counter % DEVICE_ROTATION_INTERVAL == 0 and counter > 0

def print_device_rotation_status(device_info):
    """Print device rotation status"""
    with PRINT_LOCK:
        print(f"{SYM_CYAN}{B}📱 Device Rotated: {device_info['brand']} {device_info['model']} (Android {device_info['android']}){R}")

# =============================================================================
# IP ROTATION (Tor) - ADDED FROM MAIN.PY
# =============================================================================

IP_ROTATION_INTERVAL = 15
ACCOUNT_COUNTER_FOR_IP_ROTATION = 0

def renew_tor_ip():
    """Renew Tor IP address via control port"""
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        s.connect(('127.0.0.1', 9051))
        s.send(b'AUTHENTICATE ""\r\n')
        s.send(b'SIGNAL NEWNYM\r\n')
        s.send(b'QUIT\r\n')
        s.close()
        time.sleep(3)

        # Verify IP change
        test_session = requests.Session()
        test_session.proxies.update({
            'http': 'socks5h://127.0.0.1:9050',
            'https': 'socks5h://127.0.0.1:9050'
        })
        test_session.verify = False
        try:
            response = test_session.get('https://check.torproject.org', timeout=15)
            if 'Congratulations' in response.text:
                with PRINT_LOCK:
                    print(f"{SYM_YELLOW}{B}✅ IP Rotated Successfully (Tor Active){R}")
                return True, "Success"
        except:
            pass

        with PRINT_LOCK:
            print(f"{SYM_YELLOW}{B}⚠️ IP Rotation attempted (Status Unknown){R}")
        return True, "Unknown"
    except Exception as e:
        with PRINT_LOCK:
            print(f"{SYM_RED}{B}❌ IP rotation failed: {e}{R}")
        return False, f"Failed: {e}"

def verify_ip_protection():
    """Verify Tor is working"""
    try:
        session = requests.Session()
        session.proxies.update({
            'http': 'socks5h://127.0.0.1:9050',
            'https': 'socks5h://127.0.0.1:9050'
        })
        session.verify = False

        response = session.get('https://check.torproject.org', timeout=15)
        is_tor = 'Congratulations' in response.text

        try:
            ip_info = session.get('https://ipinfo.io/json', timeout=10).json()
            ip = ip_info.get('ip', 'Unknown')
            country = ip_info.get('country', 'Unknown')
            with PRINT_LOCK:
                print(f"{SYM_CYAN}🌍 Current IP: {ip} ({country}) - Tor: {'✅' if is_tor else '❌'}{R}")
        except:
            with PRINT_LOCK:
                print(f"{SYM_CYAN}🌍 Tor Status: {'✅ Active' if is_tor else '❌ Inactive'}{R}")

        return is_tor
    except Exception as e:
        with PRINT_LOCK:
            print(f"{SYM_RED}❌ IP verification failed: {e}{R}")
        return False

# =============================================================================
# PROXY CONFIGURATION
# =============================================================================

def get_proxies():
    """Get proxy configuration for Tor"""
    return {
        'http': 'socks5h://127.0.0.1:9050',
        'https': 'socks5h://127.0.0.1:9050'
    }

# ========== CONFIGURATION ==========
REGION_LANG = {"ME":"ar","IND":"hi","ID":"id","VN":"vi","TH":"th","BD":"bn","PK":"ur","TW":"zh","CIS":"ru","SAC":"es","BR":"pt"}
HEX_KEY = bytes.fromhex("32656534343831396539623435393838343531343130363762323831363231383734643064356437616639643866376530306331653534373135623764316533")

EXIT_FLAG = False
SUCCESS_COUNTER = 0
RARE_COUNTER = 0
COUPLES_COUNTER = 0
RARITY_SCORE_THRESHOLD = 4
LOCK = threading.Lock()
PRINT_LOCK = threading.Lock()
START_TIME = 0

# ========== FOLDER SETUP ==========
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_FOLDER = os.path.join(CURRENT_DIR, "GEN")
TOKENS_FOLDER = os.path.join(BASE_FOLDER, "TOKENS-JWT")
ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "ACCOUNTS")
RARE_ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "RARE ACCOUNTS")
COUPLES_ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "COUPLES ACCOUNTS")
GHOST_FOLDER = os.path.join(BASE_FOLDER, "GHOST")
GHOST_ACCOUNTS_FOLDER = os.path.join(GHOST_FOLDER, "ACCOUNTS")
GHOST_RARE_FOLDER = os.path.join(GHOST_FOLDER, "RAREACCOUNT")
GHOST_COUPLES_FOLDER = os.path.join(GHOST_FOLDER, "COUPLESACCOUNT")
ACTIVATED_FOLDER = os.path.join(BASE_FOLDER, "ACTIVATED")

for folder in [BASE_FOLDER, TOKENS_FOLDER, ACCOUNTS_FOLDER, RARE_ACCOUNTS_FOLDER, COUPLES_ACCOUNTS_FOLDER,
               GHOST_FOLDER, GHOST_ACCOUNTS_FOLDER, GHOST_RARE_FOLDER, GHOST_COUPLES_FOLDER, ACTIVATED_FOLDER]:
    os.makedirs(folder, exist_ok=True)

# ========== UTILITIES ==========
FILE_LOCKS = {}
def get_lock(fname):
    if fname not in FILE_LOCKS:
        FILE_LOCKS[fname] = threading.Lock()
    return FILE_LOCKS[fname]

PATTERNS = {
    "R4": [r"(\d)\1{3,}", 3], "R3": [r"(\d)\1\1(\d)\2\2", 2],
    "S5": [r"(12345|23456|34567|45678|56789)", 4], "S4": [r"(0123|1234|2345|3456|4567|5678|6789|9876|8765|7654|6543|5432|4321|3210)", 3],
    "P6": [r"^(\d)(\d)(\d)\3\2\1$", 5], "P4": [r"^(\d)(\d)\2\1$", 3],
    "SPH": [r"(69|420|1337|007)", 4], "SPM": [r"(100|200|300|400|500|666|777|888|999)", 2],
    "QD": [r"(1111|2222|3333|4444|5555|6666|7777|8888|9999|0000)", 4],
    "MH": [r"^(\d{2,3})\1$", 3], "MM": [r"(\d{2})0\1", 2], "GD": [r"1618|0618", 3]
}

COUPLES_DATA = {}
COUPLES_LOCK = threading.Lock()

def check_rarity(account_data):
    account_id = account_data.get("account_id", "")
    if not account_id or account_id == "N/A":
        return False, None, None, 0
    score = 0
    patterns_found = []
    for ptype, (pattern, pts) in PATTERNS.items():
        if re.search(pattern, account_id):
            score += pts
            patterns_found.append(ptype)
    digits = [int(d) for d in account_id if d.isdigit()]
    if len(set(digits)) == 1 and len(digits) >= 4:
        score += 5
        patterns_found.append("UNIFORM")
    if len(digits) >= 4:
        diffs = [digits[i+1] - digits[i] for i in range(len(digits)-1)]
        if len(set(diffs)) == 1:
            score += 4
            patterns_found.append("ARITHMETIC")
    if len(account_id) <= 8 and account_id.isdigit() and int(account_id) < 1000000:
        score += 3
        patterns_found.append("LOW_ID")
    if score >= RARITY_SCORE_THRESHOLD:
        reason = f"ID:{account_id} | Score:{score} | {','.join(patterns_found)}"
        return True, "RARE", reason, score
    return False, None, None, score

def check_couple(account_data, thread_id):
    account_id = account_data.get("account_id", "")
    if not account_id or account_id == "N/A":
        return False, None, None
    with COUPLES_LOCK:
        for stored_id, stored in list(COUPLES_DATA.items()):
            stored_aid = stored.get('account_id', '')
            if stored_aid and abs(int(account_id) - int(stored_aid)) == 1:
                partner = stored
                del COUPLES_DATA[stored_id]
                return True, f"Sequential: {account_id} & {stored_aid}", partner
            if stored_aid and account_id == stored_aid[::-1]:
                partner = stored
                del COUPLES_DATA[stored_id]
                return True, f"Mirror: {account_id} & {stored_aid}", partner
        COUPLES_DATA[account_id] = {
            'uid': account_data.get('uid', ''),
            'account_id': account_id,
            'name': account_data.get('name', ''),
            'password': account_data.get('password', ''),
            'region': account_data.get('region', ''),
            'thread_id': thread_id,
            'timestamp': datetime.now().isoformat()
        }
    return False, None, None

def save_normal_account(account_data, region, is_ghost=False):
    try:
        filename = os.path.join(GHOST_ACCOUNTS_FOLDER, "ghost.json") if is_ghost else os.path.join(ACCOUNTS_FOLDER, f"accounts-{region}.json")
        entry = {
            'uid': account_data["uid"], 'password': account_data["password"],
            'account_id': account_data.get("account_id", "N/A"), 'name': account_data["name"],
            'region': "VAI" if is_ghost else region,
            'date_created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'thread_id': account_data.get('thread_id', 'N/A')
        }
        with get_lock(filename) as lock:
            data = []
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except:
                    data = []
            existing = [x.get('account_id') for x in data]
            if account_data.get("account_id", "N/A") not in existing:
                data.append(entry)
                with open(filename + '.tmp', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(filename + '.tmp', filename)
                return True
        return False
    except:
        return False

def save_rare_account(account_data, rtype, reason, rscore, is_ghost=False):
    try:
        filename = os.path.join(GHOST_RARE_FOLDER, "rare-ghost.json") if is_ghost else os.path.join(RARE_ACCOUNTS_FOLDER, f"rare-{account_data.get('region', 'UNKNOWN')}.json")
        entry = {
            'uid': account_data["uid"], 'password': account_data["password"],
            'account_id': account_data.get("account_id", "N/A"), 'name': account_data["name"],
            'region': "VAI" if is_ghost else account_data.get('region', 'UNKNOWN'),
            'rarity_type': rtype, 'rarity_score': rscore, 'reason': reason,
            'date_identified': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'jwt_token': account_data.get('jwt_token', ''), 'thread_id': account_data.get('thread_id', 'N/A')
        }
        with get_lock(filename) as lock:
            data = []
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except:
                    data = []
            existing = [x.get('account_id') for x in data]
            if account_data.get("account_id", "N/A") not in existing:
                data.append(entry)
                with open(filename + '.tmp', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(filename + '.tmp', filename)
                return True
        return False
    except:
        return False

def save_couple_account(acc1, acc2, reason, is_ghost=False):
    try:
        filename = os.path.join(GHOST_COUPLES_FOLDER, "couples-ghost.json") if is_ghost else os.path.join(COUPLES_ACCOUNTS_FOLDER, f"couples-{acc1.get('region', 'UNKNOWN')}.json")
        couple_id = f"{acc1.get('account_id', 'N/A')}_{acc2.get('account_id', 'N/A')}"
        entry = {
            'couple_id': couple_id, 'account1': acc1, 'account2': acc2,
            'reason': reason, 'region': "VAI" if is_ghost else acc1.get('region', 'UNKNOWN'),
            'date_matched': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        with get_lock(filename) as lock:
            data = []
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except:
                    data = []
            existing = [x.get('couple_id') for x in data]
            if couple_id not in existing:
                data.append(entry)
                with open(filename + '.tmp', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(filename + '.tmp', filename)
                return True
        return False
    except:
        return False

def save_jwt_token(account_data, jwt_token, region, is_ghost=False):
    try:
        filename = os.path.join(GHOST_FOLDER, "tokens-ghost.json") if is_ghost else os.path.join(TOKENS_FOLDER, f"tokens-{region}.json")
        entry = {
            'uid': account_data["uid"], 'account_id': account_data.get("account_id", "N/A"),
            'jwt_token': jwt_token, 'name': account_data["name"], 'password': account_data["password"],
            'date_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'region': "VAI" if is_ghost else region, 'thread_id': account_data.get('thread_id', 'N/A')
        }
        with get_lock(filename) as lock:
            data = []
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except:
                    data = []
            existing = [x.get('account_id') for x in data]
            if account_data.get("account_id", "N/A") not in existing:
                data.append(entry)
                with open(filename + '.tmp', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(filename + '.tmp', filename)
                return True
        return False
    except:
        return False

def save_activated_account(account_data, region):
    """Save successfully activated account to ACTIVATED folder."""
    try:
        filename = os.path.join(ACTIVATED_FOLDER, f"accounts-{region}.json")
        entry = {
            'uid': account_data["uid"],
            'password': account_data["password"],
            'account_id': account_data.get("account_id", "N/A"),
            'name': account_data["name"],
            'region': region,
            'activation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'thread_id': account_data.get('thread_id', 'N/A')
        }
        with get_lock(filename) as lock:
            data = []
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except:
                    data = []
            existing = [x.get('account_id') for x in data]
            if account_data.get("account_id", "N/A") not in existing:
                data.append(entry)
                with open(filename + '.tmp', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(filename + '.tmp', filename)
                return True
        return False
    except:
        return False

# ========== NETWORK & CRYPTO (UPDATED WITH DEVICE HEADERS) ==========
def encode_varint(n):
    if n < 0:
        return b''
    result = []
    while True:
        byte = n & 0x7F
        n >>= 7
        if n:
            byte |= 0x80
        result.append(byte)
        if not n:
            break
    return bytes(result)

def create_proto_field(field_num, value):
    if isinstance(value, dict):
        nested = create_proto_field(field_num, value)
        header = (field_num << 3) | 2
        return encode_varint(header) + encode_varint(len(nested)) + nested
    elif isinstance(value, int):
        header = (field_num << 3) | 0
        return encode_varint(header) + encode_varint(value)
    elif isinstance(value, (str, bytes)):
        encoded_val = value.encode() if isinstance(value, str) else value
        header = (field_num << 3) | 2
        return encode_varint(header) + encode_varint(len(encoded_val)) + encoded_val
    return b''

def build_proto(fields):
    return b''.join(create_proto_field(k, v) for k, v in fields.items())

def aes_encrypt(hex_data):
    data = bytes.fromhex(hex_data)
    aes_key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(aes_key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(data, AES.block_size))

def encrypt_api(plain_hex):
    plain = bytes.fromhex(plain_hex)
    aes_key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(aes_key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(plain, AES.block_size)).hex()

def generate_exponent():
    exp_digits = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'}
    num = random.randint(1, 9999)
    return ''.join(exp_digits[d] for d in f"{num:04d}")

def generate_random_name(base):
    return f"{base}{generate_exponent()}"

def generate_custom_password(user_prefix):
    random_part = ''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for _ in range(8))
    return f"{user_prefix}_{_HIDDEN}_{random_part}"

# ========== OPTIMIZED NETWORK: SESSION POOLING WITH DEVICE ROTATION ==========
thread_local = threading.local()

def get_session(force_new=False):
    """Get or create session with proxy and current device headers"""
    if force_new or not hasattr(thread_local, "session"):
        thread_local.session = requests.Session()
        thread_local.session.verify = False
        thread_local.session.timeout = 10
        
        # Set proxy for Tor
        thread_local.session.proxies.update(get_proxies())
        
        # Set device headers
        device = get_current_device()
        thread_local.session.headers.update({
            'User-Agent': device['user_agent'],
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'X-Device-Model': device['model'],
            'X-Device-Brand': device['brand']
        })
    return thread_local.session

def update_session_device(session):
    """Update session headers with current device"""
    device = get_current_device()
    session.headers.update({
        'User-Agent': device['user_agent'],
        'X-Device-Model': device['model'],
        'X-Device-Brand': device['brand']
    })

def create_account(region, account_name, password_prefix, is_ghost=False):
    if EXIT_FLAG:
        return None
    session = get_session()
    for _ in range(3):
        try:
            password = generate_custom_password(password_prefix)
            url = "https://100067.connect.garena.com/api/v2/oauth/guest:register"
            payload = {"app_id": 100067, "client_type": 2, "password": password, "source": 2}
            headers = {
                "Accept": "application/json", "Content-Type": "application/json; charset=utf-8",
                "Accept-Encoding": "gzip", "Connection": "Keep-Alive"
            }
            response = session.post(url, headers=headers, json=payload, timeout=10)
            response.raise_for_status()
            res_json = response.json()
            if "data" in res_json and "uid" in res_json["data"]:
                uid = res_json["data"]["uid"]
                return get_token(uid, password, region, account_name, password_prefix, is_ghost)
        except:
            continue
    return None

def get_token(uid, password, region, account_name, password_prefix, is_ghost=False):
    if EXIT_FLAG:
        return None
    session = get_session()
    for _ in range(3):
        try:
            url = "https://100067.connect.garena.com/oauth/guest/token/grant"
            headers = {
                "Accept-Encoding": "gzip", "Connection": "Keep-Alive",
                "Content-Type": "application/x-www-form-urlencoded", "Host": "100067.connect.garena.com",
            }
            body = {"uid": uid, "password": password, "response_type": "token", "client_type": "2", "client_secret": HEX_KEY, "client_id": "100067"}
            response = session.post(url, headers=headers, data=body, timeout=10)
            response.raise_for_status()
            if 'open_id' in response.json():
                open_id = response.json()['open_id']
                access_token = response.json()["access_token"]
                keystream = [0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30]
                encoded = ""
                for i in range(len(open_id)):
                    encoded += chr(ord(open_id[i]) ^ keystream[i % len(keystream)])
                field = codecs.decode(''.join(c if 32 <= ord(c) <= 126 else f'\\u{ord(c):04x}' for c in encoded), 'unicode_escape').encode('latin1')
                return major_register(access_token, open_id, field, uid, password, region, account_name, password_prefix, is_ghost)
        except:
            continue
    return None

def major_register(access_token, open_id, field, uid, password, region, account_name, password_prefix, is_ghost=False):
    if EXIT_FLAG:
        return None
    session = get_session()
    for _ in range(3):
        try:
            if is_ghost:
                url = "https://loginbp.ggblueshark.com/MajorRegister"
            elif region.upper() in ["ME", "TH"]:
                url = "https://loginbp.common.ggbluefox.com/MajorRegister"
            else:
                url = "https://loginbp.ggblueshark.com/MajorRegister"
            name = generate_random_name(account_name)
            headers = {
                "Accept-Encoding": "gzip", "Authorization": "Bearer", "Connection": "Keep-Alive",
                "Content-Type": "application/x-www-form-urlencoded", "Expect": "100-continue",
                "Host": "loginbp.ggblueshark.com" if is_ghost or region.upper() not in ["ME","TH"] else "loginbp.common.ggbluefox.com",
                "ReleaseVersion": "OB53", "X-GA": "v1 1", "X-Unity-Version": "2018.4."
            }
            lang_code = "pt" if is_ghost else REGION_LANG.get(region.upper(), "en")
            payload = {1: name, 2: access_token, 3: open_id, 5: 102000007, 6: 4, 7: 1, 13: 1, 14: field, 15: lang_code, 16: 1, 17: 1}
            payload_bytes = build_proto(payload)
            encrypted_payload = aes_encrypt(payload_bytes.hex())
            session.post(url, headers=headers, data=encrypted_payload, timeout=10)
            login_result = major_login(uid, password, access_token, open_id, region, is_ghost)
            account_id = login_result.get("account_id", "N/A")
            jwt_token = login_result.get("jwt_token", "")
            if account_id != "N/A":
                if not is_ghost and jwt_token and region.upper() != "BR":
                    try:
                        force_region_bind(region, jwt_token)
                    except:
                        pass
                return {
                    "uid": uid, "password": password, "name": name,
                    "region": "GHOST" if is_ghost else region, "status": "success",
                    "account_id": account_id, "jwt_token": jwt_token
                }
        except:
            continue
    return None

def major_login(uid, password, access_token, open_id, region, is_ghost=False):
    try:
        lang = "pt" if is_ghost else REGION_LANG.get(region.upper(), "en")
        payload_parts = [
            b'\x1a\x132025-08-30 05:19:21"\tfree fire(\x01:\x081.114.13B2Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)J\x08HandheldR\nATM MobilsZ\x04WIFI`\xb6\nh\xee\x05r\x03300z\x1fARMv7 VFPv3 NEON VMH | 2400 | 2\x80\x01\xc9\x0f\x8a\x01\x0fAdreno (TM) 640\x92\x01\rOpenGL ES 3.2\x9a\x01+Google|dfa4ab4b-9dc4-454e-8065-e70c733fa53f\xa2\x01\x0e105.235.139.91\xaa\x01\x02',
            lang.encode("ascii"),
            b'\xb2\x01 1d8ec0240ede109973f3321b9354b44d\xba\x01\x014\xc2\x01\x08Handheld\xca\x01\x10Asus ASUS_I005DA\xea\x01@afcfbf13334be42036e4f742c80b956344bed760ac91b3aff9b607a610ab4390\xf0\x01\x01\xca\x02\nATM Mobils\xd2\x02\x04WIFI\xca\x03 7428b253defc164018c604a1ebbfebdf\xe0\x03\xa8\x81\x02\xe8\x03\xf6\xe5\x01\xf0\x03\xaf\x13\xf8\x03\x84\x07\x80\x04\xe7\xf0\x01\x88\x04\xa8\x81\x02\x90\x04\xe7\xf0\x01\x98\x04\xa8\x81\x02\xc8\x04\x01\xd2\x04=/data/app/com.dts.freefireth-PdeDnOilCSFn37p1AH_FLg==/lib/arm\xe0\x04\x01\xea\x04_2087f61c19f57f2af4e7feff0b24d9d9|/data/app/com.dts.freefireth-PdeDnOilCSFn37p1AH_FLg==/base.apk\xf0\x04\x03\xf8\x04\x01\x8a\x05\x0232\x9a\x05\n2019118692\xb2\x05\tOpenGLES2\xb8\x05\xff\x7f\xc0\x05\x04\xe0\x05\xf3F\xea\x05\x07android\xf2\x05pKqsHT5ZLWrYljNb5Vqh//yFRlaPHSO9NWSQsVvOmdhEEn7W+VHNUK+Q+fduA3ptNrGB0Ll0LRz3WW0jOwesLj6aiU7sZ40p8BfUE/FI/jzSTwRe2\xf8\x05\xfb\xe4\x06\x88\x06\x01\x90\x06\x01\x9a\x06\x014\xa2\x06\x014\xb2\x06"GQ@O\x00\x0e^\x00D\x06UA\x0ePM\r\x13hZ\x07T\x06\x0cm\\V\x0ejYV;\x0bU5'
        ]
        payload = b''.join(payload_parts)
        if is_ghost:
            url = "https://loginbp.ggblueshark.com/MajorLogin"
        elif region.upper() in ["ME", "TH"]:
            url = "https://loginbp.common.ggbluefox.com/MajorLogin"
        else:
            url = "https://loginbp.ggblueshark.com/MajorLogin"
        headers = {
            "Accept-Encoding": "gzip", "Authorization": "Bearer", "Connection": "Keep-Alive",
            "Content-Type": "application/x-www-form-urlencoded", "Expect": "100-continue",
            "Host": "loginbp.ggblueshark.com" if is_ghost or region.upper() not in ["ME","TH"] else "loginbp.common.ggbluefox.com",
            "ReleaseVersion": "OB53", "X-GA": "v1 1", "X-Unity-Version": "2018.4.11f1"
        }
        data = payload.replace(b'afcfbf13334be42036e4f742c80b956344bed760ac91b3aff9b607a610ab4390', access_token.encode())
        data = data.replace(b'1d8ec0240ede109973f3321b9354b44d', open_id.encode())
        d = encrypt_api(data.hex())
        session = get_session()
        response = session.post(url, headers=headers, data=bytes.fromhex(d), timeout=10)
        if response.status_code == 200 and len(response.text) > 10:
            jwt_start = response.text.find("eyJ")
            if jwt_start != -1:
                jwt_token = response.text[jwt_start:]
                second_dot = jwt_token.find(".", jwt_token.find(".") + 1)
                if second_dot != -1:
                    jwt_token = jwt_token[:second_dot + 44]
                    try:
                        parts = jwt_token.split('.')
                        if len(parts) >= 2:
                            payload_part = parts[1]
                            padding = 4 - len(payload_part) % 4
                            if padding != 4:
                                payload_part += '=' * padding
                            decoded = base64.urlsafe_b64decode(payload_part)
                            data = json.loads(decoded)
                            account_id = data.get('account_id') or data.get('external_id')
                            if account_id:
                                return {"account_id": str(account_id), "jwt_token": jwt_token}
                    except:
                        pass
        return {"account_id": "N/A", "jwt_token": ""}
    except:
        return {"account_id": "N/A", "jwt_token": ""}

def force_region_bind(region, jwt_token):
    try:
        url = "https://loginbp.common.ggbluefox.com/ChooseRegion" if region.upper() in ["ME","TH"] else "https://loginbp.ggblueshark.com/ChooseRegion"
        region_code = "RU" if region.upper() == "CIS" else region.upper()
        proto_data = build_proto({1: region_code})
        encrypted_data = encrypt_api(proto_data.hex())
        payload = bytes.fromhex(encrypted_data)
        headers = {
            'Connection': "Keep-Alive", 'Accept-Encoding': "gzip",
            'Content-Type': "application/x-www-form-urlencoded", 'Expect': "100-continue",
            'Authorization': f"Bearer {jwt_token}", 'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1", 'ReleaseVersion': "OB53"
        }
        session = get_session()
        session.post(url, data=payload, headers=headers, timeout=10)
    except:
        pass

# ========== MULTI-REGION ACTIVATOR ==========
class MultiRegionActivator:
    """Ultra‑fast, region‑aware auto‑activator for all Free Fire regions."""
    
    def __init__(self, max_workers=10, turbo_mode=True):
        self.key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
        self.iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
        self.turbo_mode = turbo_mode
        self.session = requests.Session()
        self.session.verify = False
        self.session.proxies.update(get_proxies())
        
        # Complete region configuration
        self.regions = {
            'IND': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://client.ind.freefiremobile.com/GetLoginData',
                'client_host': 'client.ind.freefiremobile.com'
            },
            'BD': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'PK': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'NA': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'LK': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'ID': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'TH': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.common.ggbluefox.com/GetLoginData',
                'client_host': 'clientbp.common.ggbluefox.com'
            },
            'VN': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'BR': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.ggpolarbear.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'ME': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'TW': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://clientbp.ggpolarbear.com/GetLoginData',
                'client_host': 'clientbp.ggpolarbear.com'
            },
            'CIS': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://client.ind.freefiremobile.com/GetLoginData',
                'client_host': 'client.ind.freefiremobile.com'
            },
            'SAC': {
                'guest_url': 'https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant',
                'major_login_url': 'https://loginbp.common.ggbluefox.com/MajorLogin',
                'get_login_data_url': 'https://client.ind.freefiremobile.com/GetLoginData',
                'client_host': 'client.ind.freefiremobile.com'
            }
        }
        
        self.session.mount('https://', requests.adapters.HTTPAdapter(pool_connections=50, pool_maxsize=50))
    
    def encrypt_api(self, plain_text):
        try:
            plain = bytes.fromhex(plain_text)
            cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
            return cipher.encrypt(pad(plain, AES.block_size)).hex()
        except:
            return None
    
    def parse_my_message(self, serialized_data):
        if MajorLoginRes_pb2 is None:
            return None, None, None
        try:
            res = MajorLoginRes_pb2.MajorLoginRes()
            res.ParseFromString(serialized_data)
            return res.token, res.ak.hex() if res.ak else None, res.aiv.hex() if res.aiv else None
        except:
            return None, None, None
    
    def guest_token(self, uid, password, region):
        cfg = self.regions.get(region)
        if not cfg:
            return None, None
        data = {
            "uid": uid,
            "password": password,
            "response_type": "token",
            "client_type": "2",
            "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
            "client_id": "100067",
        }
        for _ in range(3):
            try:
                resp = self.session.post(cfg['guest_url'], data=data, timeout=8)
                if resp.status_code == 200:
                    js = resp.json()
                    return js.get('access_token'), js.get('open_id')
            except:
                pass
        return None, None
    
    def major_login(self, access_token, open_id, region):
        cfg = self.regions.get(region)
        if not cfg:
            return None
        template = bytes.fromhex(
            '1a13323032352d30372d33302031313a30323a3531220966726565206669726528013a07312e3131342e32422c416e64726f6964204f5320372e312e32202f204150492d323320284e32473438482f373030323530323234294a0848616e6468656c645207416e64726f69645a045749464960c00c68840772033332307a1f41524d7637205646507633204e454f4e20564d48207c2032343635207c203480019a1b8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e319a012b476f6f676c657c31663361643662372d636562342d343934622d383730622d623164616364373230393131a2010c3139372e312e31322e313335aa0102656eb201203939366136323964626364623339363462653662363937386635643831346462ba010134c2010848616e6468656c64ca011073616d73756e6720534d2d473935354eea014066663930633037656239383135616633306134336234613966363031393531366530653463373033623434303932353136643064656661346365663531663261f00101ca0207416e64726f6964d2020457494649ca03203734323862323533646566633136343031386336303461316562626665626466e003daa907e803899b07f003bf0ff803ae088004999b078804daa9079004999b079804daa907c80403d204262f646174612f6170702f636f6d2e6474732e667265656669726574682d312f6c69622f61726de00401ea044832303837663631633139663537663261663465376665666630623234643964397c2f646174612f6170702f636f6d2e6474732e667265656669726574682d312f626173652e61706bf00403f804018a050233329a050a32303139313138363933a80503b205094f70656e474c455332b805ff7fc00504e005dac901ea0507616e64726f6964f2055c4b71734854394748625876574c6668437950416c52526873626d43676542557562555551317375746d525536634e30524f3751453141486e496474385963784d614c575437636d4851322b7374745279377830663935542b6456593d8806019006019a060134a2060134b2061e40001147550d0c074f530b4d5c584d57416657545a065f2a091d6a0d5033'
        )
        old_open = b"996a629dbcdb3964be6b6978f5d814db"
        old_token = b"ff90c07eb9815af30a43b4a9f6019516e0e4c703b44092516d0defa4cef51f2a"
        payload = template.replace(old_open, open_id.encode()).replace(old_token, access_token.encode())
        encrypted = self.encrypt_api(payload.hex())
        if not encrypted:
            return None
        headers = {
            'X-Unity-Version': '2018.4.11f1',
            'ReleaseVersion': 'OB53',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-GA': 'v1 1',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
            'Host': cfg['major_login_url'].split('/')[2],
            'Connection': 'Keep-Alive',
        }
        for _ in range(3):
            try:
                resp = self.session.post(cfg['major_login_url'], headers=headers, data=bytes.fromhex(encrypted), timeout=10)
                if resp.status_code == 200 and len(resp.content) > 0:
                    return resp.content
            except:
                pass
        return None
    
    def GET_PAYLOAD_BY_DATA(self, jwt_token, access_token, region):
        try:
            b64 = jwt_token.split('.')[1]
            b64 += '=' * ((4 - len(b64) % 4) % 4)
            decoded = json.loads(base64.urlsafe_b64decode(b64).decode())
            ext_id = decoded['external_id']
            sig_md5 = decoded['signature_md5']
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            payload = bytes.fromhex(
                "1a13323032352d30372d33302031313a30323a3531220966726565206669726528013a07312e3131342e32422c416e64726f6964204f5320372e312e32202f204150492d323320284e32473438482f373030323530323234294a0848616e6468656c645207416e64726f69645a045749464960c00c68840772033332307a1f41524d7637205646507633204e454f4e20564d48207c2032343635207c203480019a1b8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e319a012b476f6f676c657c31663361643662372d636562342d343934622d383730622d623164616364373230393131a2010c3139372e312e31322e313335aa0102656eb201203939366136323964626364623339363462653662363937386635643831346462ba010134c2010848616e6468656c64ca011073616d73756e6720534d2d473935354eea014066663930633037656239383135616633306134336234613966363031393531366530653463373033623434303932353136643064656661346365663531663261f00101ca0207416e64726f6964d2020457494649ca03203734323862323533646566633136343031386336303461316562626665626466e003daa907e803899b07f003bf0ff803ae088004999b078804daa9079004999b079804daa907c80403d204262f646174612f6170702f636f6d2e6474732e667265656669726574682d312f6c69622f61726de00401ea044832303837663631633139663537663261663465376665666630623234643964397c2f646174612f6170702f636f6d2e6474732e667265656669726574682d312f626173652e61706bf00403f804018a050233329a050a32303139313138363933a80503b205094f70656e474c455332b805ff7fc00504e005dac901ea0507616e64726f6964f2055c4b71734854394748625876574c6668437950416c52526873626d43676542557562555551317375746d525536634e30524f3751453141486e496474385963784d614c575437636d4851322b7374745279377830663935542b6456593d8806019006019a060134a2060134b2061e40001147550d0c074f530b4d5c584d57416657545a065f2a091d6a0d5033"
            )
            payload = payload.replace(b"2025-07-30 11:02:51", now.encode())
            payload = payload.replace(b"ff90c07eb9815af30a43b4a9f6019516e0e4c703b44092516d0defa4cef51f2a", access_token.encode())
            payload = payload.replace(b"996a629dbcdb3964be6b6978f5d814db", ext_id.encode())
            payload = payload.replace(b"7428b253defc164018c604a1ebbfebdf", sig_md5.encode())
            enc = self.encrypt_api(payload.hex())
            return bytes.fromhex(enc) if enc else None
        except:
            return None
    
    def GET_LOGIN_DATA(self, jwt_token, payload, region):
        cfg = self.regions.get(region)
        if not cfg:
            return False
        headers = {
            'Expect': '100-continue',
            'Authorization': f'Bearer {jwt_token}',
            'X-Unity-Version': '2018.4.11f1',
            'X-GA': 'v1 1',
            'ReleaseVersion': 'OB53',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
            'Host': cfg['client_host'],
            'Connection': 'close',
        }
        for _ in range(2):
            try:
                resp = self.session.post(cfg['get_login_data_url'], headers=headers, data=payload, timeout=8)
                if resp.status_code == 200:
                    return True
            except:
                pass
        return False
    
    def activate_single_account(self, account_data):
        """Activate a single account using its own region field."""
        uid = account_data['uid']
        password = account_data['password']
        region = account_data.get('region')
        
        if region == 'GHOST' or region not in self.regions:
            return False
        
        acc_token, open_id = self.guest_token(uid, password, region)
        if not acc_token or not open_id:
            return False
        
        major_resp = self.major_login(acc_token, open_id, region)
        if not major_resp:
            return False
        
        jwt_token, _, _ = self.parse_my_message(major_resp)
        if not jwt_token:
            return False
        
        payload = self.GET_PAYLOAD_BY_DATA(jwt_token, acc_token, region)
        if not payload:
            return False
        
        success = self.GET_LOGIN_DATA(jwt_token, payload, region)
        if success:
            with PRINT_LOCK:
                print(f"{SYM_YELLOW}🎉 ACTIVATED: {account_data['name']} ({account_data.get('account_id','N/A')}) in {region}{R}")
        return success

# ========== GLOBAL ACTIVATOR INSTANCE ==========
activator = MultiRegionActivator(max_workers=10, turbo_mode=True)

# ========== ACTIVATION BACKGROUND WORKER ==========
def activate_and_save(account_data):
    """Thread target: activate and save if successful (non‑blocking)."""
    if account_data.get('region') == 'GHOST':
        with PRINT_LOCK:
            print(f"{SYM_RED}⚠️  Ghost account skipped activation: {account_data['name']}{R}")
        return
    with PRINT_LOCK:
        print(f"{SYM_CYAN}⚡ ACTIVATING... {account_data['name']}{R}")
    success = activator.activate_single_account(account_data)
    if success:
        save_activated_account(account_data, account_data['region'])

# ========== ULTRA FAST UI - NO DELAYS ==========
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def build_box(top, bottom, lines, sep=None):
    parts = [top]
    if sep:
        parts.append(sep)
    parts.extend(lines)
    parts.append(bottom)
    return '\n'.join(parts)

def gradient_progress_bar(current, total, length=30):
    percent = current / total if total else 0
    filled = int(length * percent)
    if percent <= 0.3:
        color = Fore.LIGHTRED_EX
    elif percent <= 0.7:
        color = Fore.LIGHTYELLOW_EX
    else:
        color = Fore.LIGHTCYAN_EX
    bar = Style.BRIGHT + color + '█' * filled + Fore.BLACK + '░' * (length - filled) + R
    return f"{bar} {VAL}{percent*100:.0f}%{R}"

def print_success_box(account_data, count, total):
    uid = account_data.get('uid', 'N/A')
    pwd = account_data.get('password', 'N/A')
    name = account_data.get('name', 'N/A')
    aid = account_data.get('account_id', 'N/A')

    top    = f"{BDR}╔═{SYM_CYAN}💎{BDR}{'═'*52}{SYM_CYAN}💎{BDR}═╗{R}"
    sep    = f"{BDR}╠═{SYM_YELLOW}⚡{BDR}{'═'*52}{SYM_YELLOW}⚡{BDR}═╣{R}"
    bottom = f"{BDR}╚═{SYM_CYAN}💎{BDR}{'═'*52}{SYM_CYAN}💎{BDR}═╝{R}"
    
    title_text = f"✅ ACCOUNT GENERATED {count}/{total}"
    title_line = f"{BDR}║{R}   {TIT}{title_text}{R}   {BDR}║{R}"

    line1 = f"{BDR}║{R} {LBL_BLUE}UID        :{R} {VAL}{uid:<40}{R} {BDR}║{R}"
    line2 = f"{BDR}║{R} {LBL_CYAN}PASSWORD   :{R} {VAL}{pwd:<40}{R} {BDR}║{R}"
    line3 = f"{BDR}║{R} {LBL_BLUE}NAME       :{R} {VAL}{name:<40}{R} {BDR}║{R}"
    line4 = f"{BDR}║{R} {LBL_CYAN}ACCOUNT ID :{R} {HIGHLIGHT}{aid:<40}{R} {BDR}║{R}"
    progress_line = f"{BDR}║{R} {gradient_progress_bar(count, total, 52)} {BDR}║{R}"

    with PRINT_LOCK:
        print(top)
        print(title_line)
        print(sep)
        print(line1)
        print(line2)
        print(line3)
        print(line4)
        print(progress_line)
        print(bottom)
        print()

def print_summary(total, rare, couples, elapsed):
    top = f"{BDR}╔═{SYM_RED}📊{BDR}{'═'*52}{SYM_RED}📊{BDR}═╗{R}"
    sep = f"{BDR}╠═{SYM_YELLOW}💠{BDR}{'═'*52}{SYM_YELLOW}💠{BDR}═╣{R}"
    bottom = f"{BDR}╚═{SYM_RED}📊{BDR}{'═'*52}{SYM_RED}📊{BDR}═╝{R}"
    title = f"{BDR}║{R}          {TIT}GENERATION SUMMARY{R}          {BDR}║{R}"
    line1 = f"{BDR}║{R} {LBL_BLUE}Accounts Generated :{R} {VAL}{total:<10}{R} {BDR}║{R}"
    line2 = f"{BDR}║{R} {LBL_CYAN}Rare Found        :{R} {VAL}{rare:<10}{R} {BDR}║{R}"
    line3 = f"{BDR}║{R} {LBL_BLUE}Couples Pairs     :{R} {VAL}{couples:<10}{R} {BDR}║{R}"
    line4 = f"{BDR}║{R} {LBL_CYAN}Time Elapsed      :{R} {VAL}{elapsed:.2f}s{R}       {BDR}║{R}"
    with PRINT_LOCK:
        print(top); print(title); print(sep); print(line1); print(line2); print(line3); print(line4); print(bottom)

def animated_banner():
    lines = [
        f"{SYM_CYAN}   ██╗   ██╗ █████╗ ██╗██████╗ ██╗  ██╗ █████╗ ██╗   ██╗",
        f"{SYM_CYAN}   ██║   ██║██╔══██╗██║██╔══██╗██║  ██║██╔══██╗██║   ██║",
        f"{SYM_CYAN}   ██║   ██║███████║██║██████╔╝███████║███████║██║   ██║",
        f"{SYM_YELLOW}   ╚██╗ ██╔╝██╔══██║██║██╔══██╗██╔══██║██╔══██║██║   ██║",
        f"{SYM_RED}    ╚████╔╝ ██║  ██║██║██████╔╝██║  ██║██║  ██║╚██████╔╝",
        f"{SYM_RED}     ╚═══╝  ╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝",
        f"{SYM_CYAN}            VAIBHAV - PREMIUM GENERATOR"
    ]
    for line in lines: print(line)
    print(f"{SYM_CYAN}╺{'═'*50}╺")

def main_menu():
    while True:
        clear_screen()
        animated_banner()
        
        # Verify IP protection on startup
        print(f"{SYM_CYAN}🔒 Verifying IP Protection...{R}")
        verify_ip_protection()
        
        top = f"{BDR}╔═{SYM_RED}🔥{BDR}{'═'*52}{SYM_RED}🔥{BDR}═╗{R}"
        sep = f"{BDR}╠═{SYM_CYAN}💎{BDR}{'═'*52}{SYM_CYAN}💎{BDR}═╣{R}"
        bottom = f"{BDR}╚═{SYM_RED}🔥{BDR}{'═'*52}{SYM_RED}🔥{BDR}═╝{R}"
        title = f"{BDR}║{R}          {TIT}VAIBHAV ACCOUNT GEN{R}          {BDR}║{R}"
        
        # Show device rotation status
        device_count = len(DEVICE_POOL)
        device_info = get_current_device()
        device_line = f"{BDR}║{R}  {SYM_CYAN}📱 Device: {device_info['brand']} {device_info['model']} (Rotates every {DEVICE_ROTATION_INTERVAL}){R} {BDR}║{R}"
        ip_line = f"{BDR}║{R}  {SYM_YELLOW}🌐 IP Rotates every {IP_ROTATION_INTERVAL} accounts{R} {BDR}║{R}"
        
        options = [
            f"{BDR}║{R}  {VAL}1{R}  {ICON_YELLOW}►{R}  {TIT}Generate Accounts{R}          {BDR}║{R}",
            f"{BDR}║{R}  {VAL}2{R}  {ICON_YELLOW}►{R}  {TIT}View Saved Accounts{R}        {BDR}║{R}",
            f"{BDR}║{R}  {VAL}3{R}  {ICON_YELLOW}►{R}  {TIT}About{R}                     {BDR}║{R}",
            f"{BDR}║{R}  {VAL}0{R}  {ICON_YELLOW}►{R}  {TIT}Exit{R}                      {BDR}║{R}",
        ]
        with PRINT_LOCK:
            print(build_box(top, bottom, [title, device_line, ip_line] + options, sep))
        try:
            choice = input(f"\n{ICON_YELLOW}➤ Option : {R}").strip()
            if choice == "1": generate_accounts_flow()
            elif choice == "2": view_saved_accounts()
            elif choice == "3": about_section()
            elif choice == "0": safe_exit()
        except KeyboardInterrupt: safe_exit()

def generate_accounts_flow():
    global SUCCESS_COUNTER, RARE_COUNTER, COUPLES_COUNTER, RARITY_SCORE_THRESHOLD, START_TIME, EXIT_FLAG, ACCOUNT_COUNTER_FOR_IP_ROTATION, current_device
    EXIT_FLAG = False
    ACCOUNT_COUNTER_FOR_IP_ROTATION = 0
    regions_list = [r for r in REGION_LANG.keys() if r != "BR"]
    clear_screen()

    top = f"{BDR}╔═{SYM_CYAN}🌍{BDR}{'═'*52}{SYM_CYAN}🌍{BDR}═╗{R}"
    sep = f"{BDR}╠═{SYM_YELLOW}🔧{BDR}{'═'*52}{SYM_YELLOW}🔧{BDR}═╣{R}"
    bottom = f"{BDR}╚═{SYM_CYAN}🌍{BDR}{'═'*52}{SYM_CYAN}🌍{BDR}═╝{R}"
    title = f"{BDR}║{R}          {TIT}SELECT REGION / MODE{R}          {BDR}║{R}"
    region_lines = []
    for i, r in enumerate(regions_list, 1):
        region_lines.append(f"{BDR}║{R} {VAL}{i:2}){R} {LBL_BLUE}{r:<10}{R} {BDR}║{R}")
    ghost_num = len(regions_list) + 1
    region_lines.append(f"{BDR}║{R} {VAL}{ghost_num:2}){R} {LBL_CYAN}GHOST Mode{R}    {BDR}║{R}")
    region_lines.append(f"{BDR}║{R} {VAL}00){R} {LBL_BLUE}Back{R}          {BDR}║{R}")
    region_lines.append(f"{BDR}║{R} {VAL}000){R} {LBL_CYAN}Exit{R}         {BDR}║{R}")
    print("\n" + build_box(top, bottom, [title] + region_lines, sep))

    selected_region = None
    is_ghost = False
    while True:
        try:
            choice = input(f"\n{ICON_YELLOW}➤ Option : {R}").strip()
            if choice == "00": return
            elif choice == "000": safe_exit()
            elif choice.isdigit():
                num = int(choice)
                if 1 <= num <= len(regions_list):
                    selected_region = regions_list[num-1]; break
                elif num == len(regions_list) + 1:
                    selected_region = "BR"; is_ghost = True; break
            else:
                if choice.upper() in regions_list:
                    selected_region = choice.upper(); break
                elif choice.upper() == "GHOST":
                    selected_region = "BR"; is_ghost = True; break
        except: pass

    clear_screen()
    set_top = f"{BDR}╔═{SYM_YELLOW}⚙️ {BDR}{'═'*52}{SYM_YELLOW}⚙️ {BDR}═╗{R}"
    set_bottom = f"{BDR}╚═{SYM_YELLOW}⚙️ {BDR}{'═'*52}{SYM_YELLOW}⚙️ {BDR}═╝{R}"
    set_title = f"{BDR}║{R}          {TIT}GENERATION SETTINGS{R}          {BDR}║{R}"
    print("\n" + build_box(set_top, set_bottom, [set_title], None))

    while True:
        try:
            account_count = int(input(f"{LBL_BLUE}➤ Total accounts : {R}"))
            if account_count > 0: break
        except: pass
    while True:
        account_name = input(f"{LBL_CYAN}➤ Name prefix : {R}").strip()
        if account_name: break
    while True:
        password_prefix = input(f"{LBL_BLUE}➤ Password prefix : {R}").strip()
        if password_prefix: break
    while True:
        try:
            rarity_threshold = int(input(f"{LBL_CYAN}➤ Rarity threshold (1-20) : {R}").strip() or "8")
            if 1 <= rarity_threshold <= 20:
                RARITY_SCORE_THRESHOLD = rarity_threshold; break
        except: pass
    
    # IP rotation interval setting
    while True:
        try:
            ip_interval = int(input(f"{LBL_BLUE}➤ IP rotation interval (accounts) [15] : {R}").strip() or "15")
            if ip_interval > 0:
                global IP_ROTATION_INTERVAL
                IP_ROTATION_INTERVAL = ip_interval
                break
        except: pass
    
    # Device rotation interval setting
    while True:
        try:
            device_interval = int(input(f"{LBL_CYAN}➤ Device rotation interval (accounts) [10] : {R}").strip() or "10")
            if device_interval > 0:
                global DEVICE_ROTATION_INTERVAL
                DEVICE_ROTATION_INTERVAL = device_interval
                break
        except: pass
    
    cpu_count = os.cpu_count() or 1
    recommended = cpu_count * 2
    while True:
        try:
            thread_count = int(input(f"{LBL_BLUE}➤ Threads (recommended {recommended}) : {R}").strip())
            if thread_count > 0: break
        except: pass

    SUCCESS_COUNTER = 0; RARE_COUNTER = 0; COUPLES_COUNTER = 0; START_TIME = time.time()
    # Reset device rotation counter
    current_device = rotate_device()
    print_device_rotation_status(current_device)
    
    print(f"{TIT}🚀 Generating {account_count} accounts...{R}\n")
    print(f"{SYM_CYAN}📱 Device Rotation: Every {DEVICE_ROTATION_INTERVAL} accounts ({len(DEVICE_POOL)} devices){R}")
    print(f"{SYM_YELLOW}🌐 IP Rotation: Every {IP_ROTATION_INTERVAL} accounts (Tor){R}\n")
    
    threads = []
    for i in range(thread_count):
        t = threading.Thread(target=worker_thread, args=(selected_region, account_name, password_prefix, account_count, i+1, is_ghost))
        t.daemon = True; t.start(); threads.append(t)
    try:
        for t in threads: t.join()
    except KeyboardInterrupt:
        EXIT_FLAG = True
        for t in threads: t.join(timeout=1)
    elapsed = time.time() - START_TIME
    print_summary(SUCCESS_COUNTER, RARE_COUNTER, COUPLES_COUNTER, elapsed)
    input(f"\n{ICON_YELLOW}➤ Press Enter to continue...{R}")

def worker_thread(region, account_name, password_prefix, total_accounts, thread_id, is_ghost=False):
    global SUCCESS_COUNTER, RARE_COUNTER, COUPLES_COUNTER, ACCOUNT_COUNTER_FOR_IP_ROTATION
    while not EXIT_FLAG:
        with LOCK:
            if SUCCESS_COUNTER >= total_accounts: break
        generate_single_account(region, account_name, password_prefix, total_accounts, thread_id, is_ghost)

def generate_single_account(region, account_name, password_prefix, total_accounts, thread_id, is_ghost=False):
    global SUCCESS_COUNTER, RARE_COUNTER, COUPLES_COUNTER, ACCOUNT_COUNTER_FOR_IP_ROTATION
    if EXIT_FLAG: return None
    
    with LOCK:
        if SUCCESS_COUNTER >= total_accounts: return None
        # Increment counter for IP rotation
        ACCOUNT_COUNTER_FOR_IP_ROTATION += 1
        current_counter = SUCCESS_COUNTER
        
        # Check if we need to rotate device
        if should_rotate_device(current_counter):
            device_info = rotate_device()
            print_device_rotation_status(device_info)
            # Force new session with updated device headers
            get_session(force_new=True)
        
        # Check if we need to rotate IP
        if ACCOUNT_COUNTER_FOR_IP_ROTATION >= IP_ROTATION_INTERVAL:
            ip_status, ip_message = renew_tor_ip()
            if ip_status:
                with PRINT_LOCK:
                    print(f"{SYM_YELLOW}{B}🌐 IP Rotation Status: {ip_message}{R}")
            else:
                with PRINT_LOCK:
                    print(f"{SYM_RED}{B}🌐 IP Rotation Status: {ip_message}{R}")
            ACCOUNT_COUNTER_FOR_IP_ROTATION = 0
            # Force new session after IP rotation
            get_session(force_new=True)
    
    account_result = create_account(region, account_name, password_prefix, is_ghost)
    if not account_result or account_result.get("account_id", "N/A") == "N/A": return None
    account_result['thread_id'] = thread_id
    with LOCK:
        SUCCESS_COUNTER += 1
        current = SUCCESS_COUNTER
    print_success_box(account_result, current, total_accounts)
    
    # Activation in background
    if not is_ghost:
        threading.Thread(target=activate_and_save, args=(account_result,), daemon=True).start()
    
    is_rare, rtype, reason, rscore = check_rarity(account_result)
    if is_rare:
        with LOCK: RARE_COUNTER += 1
        save_rare_account(account_result, rtype, reason, rscore, is_ghost)
    is_couple, creason, partner = check_couple(account_result, thread_id)
    if is_couple and partner:
        with LOCK: COUPLES_COUNTER += 1
        save_couple_account(account_result, partner, creason, is_ghost)
    save_normal_account(account_result, "GHOST" if is_ghost else region, is_ghost)
    if account_result.get('jwt_token'):
        save_jwt_token(account_result, account_result['jwt_token'], "GHOST" if is_ghost else region, is_ghost)
    return {"account": account_result}

def view_saved_accounts():
    clear_screen()
    top = f"{BDR}╔═{SYM_CYAN}📁{BDR}{'═'*52}{SYM_CYAN}📁{BDR}═╗{R}"
    sep = f"{BDR}╠═{SYM_YELLOW}💾{BDR}{'═'*52}{SYM_YELLOW}💾{BDR}═╣{R}"
    bottom = f"{BDR}╚═{SYM_CYAN}📁{BDR}{'═'*52}{SYM_CYAN}📁{BDR}═╝{R}"
    title = f"{BDR}║{R}          {TIT}SAVED ACCOUNTS STATS{R}          {BDR}║{R}"
    total_normal = total_rare = total_couples = 0
    
    if os.path.exists(ACCOUNTS_FOLDER):
        for f in os.listdir(ACCOUNTS_FOLDER):
            if f.startswith("accounts-") and f.endswith(".json"):
                try:
                    with open(os.path.join(ACCOUNTS_FOLDER, f), 'r') as fp:
                        data = json.load(fp)
                        total_normal += len(data)
                except: pass
    if os.path.exists(GHOST_ACCOUNTS_FOLDER):
        try:
            with open(os.path.join(GHOST_ACCOUNTS_FOLDER, "ghost.json"), 'r') as fp:
                data = json.load(fp)
                total_normal += len(data)
        except: pass
    
    if os.path.exists(RARE_ACCOUNTS_FOLDER):
        for f in os.listdir(RARE_ACCOUNTS_FOLDER):
            if f.startswith("rare-") and f.endswith(".json"):
                try:
                    with open(os.path.join(RARE_ACCOUNTS_FOLDER, f), 'r') as fp:
                        data = json.load(fp)
                        total_rare += len(data)
                except: pass
    if os.path.exists(GHOST_RARE_FOLDER):
        try:
            with open(os.path.join(GHOST_RARE_FOLDER, "rare-ghost.json"), 'r') as fp:
                data = json.load(fp)
                total_rare += len(data)
        except: pass
    
    if os.path.exists(COUPLES_ACCOUNTS_FOLDER):
        for f in os.listdir(COUPLES_ACCOUNTS_FOLDER):
            if f.startswith("couples-") and f.endswith(".json"):
                try:
                    with open(os.path.join(COUPLES_ACCOUNTS_FOLDER, f), 'r') as fp:
                        data = json.load(fp)
                        total_couples += len(data)
                except: pass
    if os.path.exists(GHOST_COUPLES_FOLDER):
        try:
            with open(os.path.join(GHOST_COUPLES_FOLDER, "couples-ghost.json"), 'r') as fp:
                data = json.load(fp)
                total_couples += len(data)
        except: pass
    
    line1 = f"{BDR}║{R} {LBL_BLUE}Normal accounts :{R} {VAL}{total_normal:<10}{R} {BDR}║{R}"
    line2 = f"{BDR}║{R} {LBL_CYAN}Rare accounts   :{R} {VAL}{total_rare:<10}{R} {BDR}║{R}"
    line3 = f"{BDR}║{R} {LBL_BLUE}Couples pairs   :{R} {VAL}{total_couples:<10}{R} {BDR}║{R}"
    with PRINT_LOCK:
        print("\n" + build_box(top, bottom, [title, line1, line2, line3], sep))
    input(f"\n{ICON_YELLOW}➤ Press Enter to continue...{R}")

def about_section():
    clear_screen()
    top = f"{BDR}╔═{SYM_CYAN}💠{BDR}{'═'*52}{SYM_CYAN}💠{BDR}═╗{R}"
    sep = f"{BDR}╠═{SYM_YELLOW}🔮{BDR}{'═'*52}{SYM_YELLOW}🔮{BDR}═╣{R}"
    bottom = f"{BDR}╚═{SYM_CYAN}💠{BDR}{'═'*52}{SYM_CYAN}💠{BDR}═╝{R}"
    title = f"{BDR}║{R}          {TIT}PREMIUM TOOL INFORMATION{R}          {BDR}║{R}"
    lines = [
        f"{BDR}║{R} {LBL_BLUE}Name       :{R} {VAL}VAIBHAV Account Generator{R}          {BDR}║{R}",
        f"{BDR}║{R} {LBL_CYAN}Version    :{R} {VAL}OB53 Premium + Auto Activation{R} {BDR}║{R}",
        f"{BDR}║{R} {LBL_BLUE}Creator    :{R} {VAL}VAIBHAV{R}             {BDR}║{R}",
        f"{BDR}║{R} {LBL_CYAN}Telegram   :{R} {VAL}@vaibhavff570{R}            {BDR}║{R}",
        f"{BDR}║{R} {LBL_BLUE}Features   :{R} {VAL}Multi-region | GHOST | Rare{R}   {BDR}║{R}",
        f"{BDR}║{R} {LBL_CYAN}           :{R} {VAL}Couples Matching | Auto Activation{R} {BDR}║{R}",
        f"{BDR}║{R} {LBL_BLUE}           :{R} {VAL}IP Rotation (Tor) | Device Rotation{R} {BDR}║{R}",
    ]
    with PRINT_LOCK:
        print("\n" + top); print(title); print(sep)
        for line in lines: print(line)
        print(bottom)
    input(f"\n{ICON_YELLOW}➤ Press Enter to continue...{R}")

def safe_exit(signum=None, frame=None):
    global EXIT_FLAG
    EXIT_FLAG = True
    print(f"\n{TIT}👋 Thank you for using Our Premium Generator with Auto-Activation{R}")
    sys.exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, safe_exit)
    signal.signal(signal.SIGTERM, safe_exit)
    try:
        main_menu()
    except KeyboardInterrupt:
        safe_exit()
        
#CREDIT:- @vaibhavff570
#JOIN :- @vaibhavff570
#GC :- @vaibhavff570
#DON'T CHANGE MY CREDIS OR FUCK YOUR MOTHER
