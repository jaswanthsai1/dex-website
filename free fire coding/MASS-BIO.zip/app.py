import requests
import binascii
import jwt
import urllib3
import json
import base64
import os
import sys
import re
import time
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
import glob
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

try:
    import my_pb2
    import output_pb2
except ImportError:
    pass

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_REGION = "IND"
LOCK = threading.Lock()

_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x13MajorLoginReq.proto\"\xfa\n\n\nMajorLogin\x12\x12\n\nevent_time\x18\x03 \x01(\t\x12\x11\n\tgame_name\x18\x04 \x01(\t\x12\x13\n\x0bplatform_id\x18\x05 \x01(\x05\x12\x16\n\x0e\x63lient_version\x18\x07 \x01(\t\x12\x17\n\x0fsystem_software\x18\x08 \x01(\t\x12\x17\n\x0fsystem_hardware\x18\t \x01(\t\x12\x18\n\x10telecom_operator\x18\n \x01(\t\x12\x14\n\x0cnetwork_type\x18\x0b \x01(\t\x12\x14\n\x0cscreen_width\x18\x0c \x01(\r\x12\x15\n\rscreen_height\x18\r \x01(\r\x12\x12\n\nscreen_dpi\x18\x0e \x01(\t\x12\x19\n\x11processor_details\x18\x0f \x01(\t\x12\x0e\n\x06memory\x18\x10 \x01(\r\x12\x14\n\x0cgpu_renderer\x18\x11 \x01(\t\x12\x13\n\x0bgpu_version\x18\x12 \x01(\t\x12\x18\n\x10unique_device_id\x18\x13 \x01(\t\x12\x11\n\tclient_ip\x18\x14 \x01(\t\x12\x10\n\x08language\x18\x15 \x01(\t\x12\x0f\n\x07open_id\x18\x16 \x01(\t\x12\x14\n\x0copen_id_type\x18\x17 \x01(\t\x12\x13\n\x0b\x64\x65vice_type\x18\x18 \x01(\t\x12\'\n\x10memory_available\x18\x19 \x01(\x0b\x32\r.GameSecurity\x12\x14\n\x0c\x61\x63\x63\x65ss_token\x18\x1d \x01(\t\x12\x17\n\x0fplatform_sdk_id\x18\x1e \x01(\x05\x12\x1a\n\x12network_operator_a\x18) \x01(\t\x12\x16\n\x0enetwork_type_a\x18* \x01(\t\x12\x1c\n\x14\x63lient_using_version\x18\x39 \x01(\t\x12\x1e\n\x16\x65xternal_storage_total\x18< \x01(\x05\x12\"\n\x1a\x65xternal_storage_available\x18= \x01(\x05\x12\x1e\n\x16internal_storage_total\x18> \x01(\x05\x12\"\n\x1ainternal_storage_available\x18? \x01(\x05\x12#\n\x1bgame_disk_storage_available\x18@ \x01(\x05\x12\x1f\n\x17game_disk_storage_total\x18\x41 \x01(\x05\x12%\n\x1d\x65xternal_sdcard_avail_storage\x18\x42 \x01(\x05\x12%\n\x1d\x65xternal_sdcard_total_storage\x18\x43 \x01(\x05\x12\x10\n\x08login_by\x18I \x01(\x05\x12\x14\n\x0clibrary_path\x18J \x01(\t\x12\x12\n\nreg_avatar\x18L \x01(\x05\x12\x15\n\rlibrary_token\x18M \x01(\t\x12\x14\n\x0c\x63hannel_type\x18N \x01(\x05\x12\x10\n\x08\x63pu_type\x18O \x01(\x05\x12\x18\n\x10\x63pu_architecture\x18Q \x01(\t\x12\x1b\n\x13\x63lient_version_code\x18S \x01(\t\x12\x14\n\x0cgraphics_api\x18V \x01(\t\x12\x1d\n\x15supported_astc_bitset\x18W \x01(\r\x12\x1a\n\x12login_open_id_type\x18X \x01(\x05\x12\x18\n\x10\x61nalytics_detail\x18Y \x01(\x0c\x12\x14\n\x0cloading_time\x18\\ \x01(\r\x12\x17\n\x0frelease_channel\x18] \x01(\t\x12\x12\n\nextra_info\x18^ \x01(\t\x12 \n\x18\x61ndroid_engine_init_flag\x18_ \x01(\r\x12\x0f\n\x07if_push\x18\x61 \x01(\x05\x12\x0e\n\x06is_vpn\x18\x62 \x01(\x05\x12\x1c\n\x14origin_platform_type\x18\x63 \x01(\t\x12\x1d\n\x15primary_platform_type\x18\x64 \x01(\t\"5\n\x0cGameSecurity\x12\x0f\n\x07version\x18\x06 \x01(\x05\x12\x14\n\x0chidden_value\x18\x08 \x01(\x04\x62\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'MajorLoginReq_pb2', _globals)
MajorLogin = _globals['MajorLogin']
GameSecurity = _globals['GameSecurity']

DESCRIPTOR2 = _descriptor_pool.Default().AddSerializedFile(b'\n\x13MajorLoginRes.proto\"|\n\rMajorLoginRes\x12\x13\n\x0b\x61\x63\x63ount_uid\x18\x01 \x01(\x04\x12\x0e\n\x06region\x18\x02 \x01(\t\x12\r\n\x05token\x18\x08 \x01(\t\x12\x0b\n\x03url\x18\n \x01(\t\x12\x11\n\ttimestamp\x18\x15 \x01(\x03\x12\x0b\n\x03key\x18\x16 \x01(\x0c\x12\n\n\x02iv\x18\x17 \x01(\x0c\x62\x06proto3')

_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR2, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR2, 'MajorLoginRes_pb2', _globals)
MajorLoginRes = _globals['MajorLoginRes']

AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

def EnCrYpt_DaTa(data_bytes):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    padded = pad(data_bytes, AES.block_size)
    return cipher.encrypt(padded)

def GeT_JwT_FrOm_AcCeSs_ToKeN(access_token):
    try:
        inspect_url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
        insp_resp = requests.get(inspect_url, timeout=10)
        
        if insp_resp.status_code != 200:
            return None, None, None
        
        insp_data = insp_resp.json()
        open_id = insp_data.get('open_id')
        
        if not open_id:
            return None, None, None
        
        platform_types = [2, 3, 4, 6, 8]
        
        for pt in platform_types:
            try:
                major = MajorLogin()
                major.event_time = "2025-03-23 12:00:00"
                major.game_name = "free fire"
                major.platform_id = 1
                major.client_version = "1.123.1"
                major.system_software = "Android OS 9 / API-28 (PQ3B.190801.10101846/G9650ZHU2ARC6)"
                major.system_hardware = "Handheld"
                major.telecom_operator = "Verizon"
                major.network_type = "WIFI"
                major.screen_width = 1920
                major.screen_height = 1080
                major.screen_dpi = "280"
                major.processor_details = "ARM64 FP ASIMD AES VMH | 2865 | 4"
                major.memory = 3003
                major.gpu_renderer = "Adreno (TM) 640"
                major.gpu_version = "OpenGL ES 3.1 v1.46"
                major.unique_device_id = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
                major.client_ip = "223.191.51.89"
                major.language = "en"
                major.open_id = open_id
                major.open_id_type = "4"
                major.device_type = "Handheld"
                major.memory_available.version = 55
                major.memory_available.hidden_value = 81
                major.access_token = access_token
                major.platform_sdk_id = 1
                major.network_operator_a = "Verizon"
                major.network_type_a = "WIFI"
                major.client_using_version = "7428b253defc164018c604a1ebbfebdf"
                major.external_storage_total = 36235
                major.external_storage_available = 31335
                major.internal_storage_total = 2519
                major.internal_storage_available = 703
                major.game_disk_storage_available = 25010
                major.game_disk_storage_total = 26628
                major.external_sdcard_avail_storage = 32992
                major.external_sdcard_total_storage = 36235
                major.login_by = 3
                major.library_path = "/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/lib/arm64"
                major.reg_avatar = 1
                major.library_token = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/base.apk"
                major.channel_type = 3
                major.cpu_type = 2
                major.cpu_architecture = "64"
                major.client_version_code = "2019118695"
                major.graphics_api = "OpenGLES2"
                major.supported_astc_bitset = 16383
                major.login_open_id_type = 4
                major.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
                major.loading_time = 13564
                major.release_channel = "android"
                major.extra_info = "KqsHTymw5/5GB23YGniUYN2/q47GATrq7eFeRatf0NkwLKEMQ0PK5BKEk72dPflAxUlEBir6Vtey83XqF593qsl8hwY="
                major.android_engine_init_flag = 110009
                major.if_push = 1
                major.is_vpn = 1
                major.origin_platform_type = str(pt)
                major.primary_platform_type = str(pt)
                
                payload = major.SerializeToString()
                encrypted_payload = EnCrYpt_DaTa(payload)
                
                url = "https://loginbp.ggblueshark.com/MajorLogin"
                headers = {
                    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; ASUS_Z01QD Build/PI)",
                    "Connection": "Keep-Alive",
                    "Accept-Encoding": "gzip",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Unity-Version": "2018.4.11f1",
                    "X-GA": "v1 1",
                    "ReleaseVersion": "OB53"
                }
                
                resp = requests.post(url, data=encrypted_payload, headers=headers, verify=False, timeout=10)
                
                if resp.status_code == 200:
                    major_res = MajorLoginRes()
                    major_res.ParseFromString(resp.content)
                    if major_res.token:
                        return major_res.token, str(major_res.account_uid), major_res.region
            except Exception as e:
                continue
        
        return None, None, None
        
    except Exception as e:
        return None, None, None

REGION_ALIASES = {
    "EUROPE": "ME", "MIDDLEEAST": "ME", "DUBAI": "ME", "UAE": "ME",
    "SAUDI": "ME", "EGYPT": "ME", "TURKEY": "ME", "PAKISTAN": "ME", "PK": "ME",
    "ASIA": "SG", "SOUTHAMERICA": "BR", "NORTH_AMERICA": "NA"
}

REGION_MAP = {
    "IND": {"update_url": "https://client.ind.freefiremobile.com/UpdateSocialBasicInfo"},
    "ME": {"update_url": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo"},
    "BD": {"update_url": "https://clientbp.ggpolarbear.com/UpdateSocialBasicInfo"},
    "PK": {"update_url": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo"},
    "SG": {"update_url": "https://clientbp.ggpolarbear.com/UpdateSocialBasicInfo"},
    "BR": {"update_url": "https://client.us.freefiremobile.com/UpdateSocialBasicInfo"},
    "NA": {"update_url": "https://client.us.freefiremobile.com/UpdateSocialBasicInfo"},
}

FREEFIRE_VERSION = "OB53"
OAUTH_URL = "https://100067.connect.garena.com/oauth/guest/token/grant"

BIO_HEADERS = {
    "Expect": "100-continue",
    "X-Unity-Version": "2018.4.11f1",
    "X-GA": "v1 1",
    "ReleaseVersion": FREEFIRE_VERSION,
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": "Dalvik/2.1.0 (Linux; Android)",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
}

_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
b'\n\ndata.proto"\xbb\x01\n\x04\x44\x61ta\x12\x0f\n\x07\x66ield_2\x18\x02 \x01(\x05\x12\x1e\n\x07\x66ield_5\x18\x05 \x01(\x0b\x32\r.EmptyMessage\x12\x1e\n\x07\x66ield_6\x18\x06 \x01(\x0b\x32\r.EmptyMessage\x12\x0f\n\x07\x66ield_8\x18\x08 \x01(\t\x12\x0f\n\x07\x66ield_9\x18\t \x01(\x05\x12\x1f\n\x08\x66ield_11\x18\x0b \x01(\x0b\x32\r.EmptyMessage\x12\x1f\n\x08\x66ield_12\x18\x0c \x01(\x0b\x32\r.EmptyMessage"\x0e\n\x0c\x45mptyMessageb\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data1_pb2', _globals)

BioData = _sym_db.GetSymbol('Data')
EmptyMessage = _sym_db.GetSymbol('EmptyMessage')

def DeCoDe_JwT_FuLl(token):
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        return {
            "uid": str(decoded.get("account_id")),
            "name": decoded.get("nickname"),
            "region": (decoded.get("lock_region") or decoded.get("region") or "").upper(),
            "country": decoded.get("country_code")
        }
    except:
        return None

def MaP_ReGiOn(jwt_region):
    if not jwt_region:
        return DEFAULT_REGION
    jwt_region = jwt_region.upper()
    if jwt_region in REGION_MAP:
        return jwt_region
    if jwt_region in REGION_ALIASES:
        return REGION_ALIASES[jwt_region]
    return DEFAULT_REGION

def _AdD_ReGiOn_PaRaM(url, region):
    parts = urlparse(url)
    q = dict(parse_qsl(parts.query, keep_blank_values=True))
    q["region"] = region
    return urlunparse((parts.scheme, parts.netloc, parts.path, parts.params, urlencode(q), parts.fragment))

def GeT_ReGiOn_UrLs(region):
    region = region.upper() if region else DEFAULT_REGION
    if region not in REGION_MAP:
        region = DEFAULT_REGION
    update_url = _AdD_ReGiOn_PaRaM(REGION_MAP[region]["update_url"], region)
    return region, update_url

def UpLoAd_BiO_ReQuEsT(jwt_token, bio_text, update_url):
    try:
        data = BioData()
        data.field_2 = 17
        data.field_5.CopyFrom(EmptyMessage())
        data.field_6.CopyFrom(EmptyMessage())
        data.field_8 = bio_text
        data.field_9 = 1
        data.field_11.CopyFrom(EmptyMessage())
        data.field_12.CopyFrom(EmptyMessage())

        data_bytes = data.SerializeToString()
        encrypted = EnCrYpt_DaTa(data_bytes)

        headers = BIO_HEADERS.copy()
        headers["Authorization"] = f"Bearer {jwt_token}"

        resp = requests.post(update_url, headers=headers, data=encrypted, verify=False)

        status = "✅ Success" if resp.status_code == 200 else "❌ Failed"
        return {
            "status": status,
            "code": resp.status_code,
            "server_response": binascii.hexlify(resp.content).decode()
        }
    except Exception as e:
        return {"status": str(e), "code": 500, "server_response": ""}

def GuEsT_loGiN(uid, password):
    try:
        payload = {
            'uid': uid, 'password': password, 'response_type': "token",
            'client_type': "2", 'client_secret': "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
            'client_id': "100067"
        }
        headers = {'User-Agent': "GarenaMSDK/4.0.19P9(SM-M526B ;Android 13;pt;BR;)"}
        
        resp = requests.post(OAUTH_URL, data=payload, headers=headers, verify=False, timeout=10)
        
        if resp.status_code == 200:
            data = resp.json()
            access_token = data.get('access_token')
            open_id = data.get('open_id')
            if access_token and open_id:
                jwt_token, account_uid, region = GeT_JwT_FrOm_AcCeSs_ToKeN(access_token)
                return jwt_token, account_uid, region
        return None, None, None
    except Exception as e:
        return None, None, None

def UpLoAd_BiO_FoR_AcCoUnT(acc, bio, index, total, results_list):
    uid = acc['uid']
    password = acc['password']
    account_name = acc.get('name')
    
    with LOCK:
        print(f"\n[{index}/{total}] 🔄 Processing UID: {uid}")
    
    jwt_token, account_uid, region = GuEsT_loGiN(str(uid), password)
    
    if not jwt_token:
        result = {
            "uid": uid,
            "name": account_name,
            "status": "❌ Login Failed",
            "code": 401,
            "region": None
        }
        with LOCK:
            print(f"[{index}/{total}] ❌ UID: {uid} - Login Failed")
        results_list.append(result)
        return result
    
    jwt_info = DeCoDe_JwT_FuLl(jwt_token)
    if not jwt_info:
        jwt_info = {"uid": account_uid, "region": region, "name": account_name}
    
    jwt_region = jwt_info.get("region") if jwt_info else DEFAULT_REGION
    mapped_region = MaP_ReGiOn(jwt_region)
    _, update_url = GeT_ReGiOn_UrLs(mapped_region)
    upload_result = UpLoAd_BiO_ReQuEsT(jwt_token, bio, update_url)
    
    result = {
        "uid": uid,
        "name": jwt_info.get("name") or account_name,
        "status": upload_result["status"],
        "code": upload_result["code"],
        "region": mapped_region,
        "server_response": upload_result["server_response"][:50] + "..."
    }
    
    with LOCK:
        if upload_result["status"] == "✅ Success":
            print(f"[{index}/{total}] ✅ UID: {uid} - Bio uploaded! | 👤 {result['name']} | 🌍 {mapped_region}")
        else:
            print(f"[{index}/{total}] ❌ UID: {uid} - Failed: {upload_result['status']}")
    
    results_list.append(result)
    return result

def PaRalLeL_Batch_UpLoAd(accounts, bio, max_workers=50):
    results = []
    total = len(accounts)
    
    print(f"\n🚀 Starting parallel upload with {max_workers} concurrent threads")
    print(f"📊 Total accounts: {total}")
    print("="*70)
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = []
        for idx, acc in enumerate(accounts, 1):
            future = executor.submit(UpLoAd_BiO_FoR_AcCoUnT, acc, bio, idx, total, results)
            futures.append(future)
        
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                with LOCK:
                    print(f"⚠️ Error in thread: {e}")
    
    return results

def LoAd_AcCoUnTs_FrOm_JSoN(filepath):
    accounts = []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    uid = item.get('uid')
                    password = item.get('password')
                    name = item.get('name')
                    
                    if uid and password:
                        accounts.append({
                            'uid': str(uid),
                            'password': str(password),
                            'name': name
                        })
        elif isinstance(data, dict):
            uid = data.get('uid')
            password = data.get('password')
            name = data.get('name')
            
            if uid and password:
                accounts.append({
                    'uid': str(uid),
                    'password': str(password),
                    'name': name
                })
        
        print(f"   ✅ Loaded {len(accounts)} accounts from JSON")
        
    except json.JSONDecodeError as e:
        print(f"   ❌ Invalid JSON format: {e}")
    except Exception as e:
        print(f"   ❌ Error reading JSON: {e}")
    
    return accounts

def DeTeCt_FiLe_FoRmAt(filepath):
    accounts = []
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        if content.strip().startswith('[') or content.strip().startswith('{'):
            try:
                json.loads(content)
                return LoAd_AcCoUnTs_FrOm_JSoN(filepath)
            except:
                pass
        
        lines = content.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if ':' in line:
                parts = line.split(':', 1)
                uid = parts[0].strip()
                password = parts[1].strip()
                
                if uid.isdigit() and len(uid) >= 8:
                    accounts.append({'uid': uid, 'password': password, 'name': None})
            
            elif '|' in line:
                parts = line.split('|', 1)
                uid = parts[0].strip()
                password = parts[1].strip()
                
                if uid.isdigit() and len(uid) >= 8:
                    accounts.append({'uid': uid, 'password': password, 'name': None})
            
            elif ',' in line:
                parts = line.split(',', 1)
                uid = parts[0].strip()
                password = parts[1].strip()
                
                if uid.isdigit() and len(uid) >= 8:
                    accounts.append({'uid': uid, 'password': password, 'name': None})
            
            elif '\t' in line:
                parts = line.split('\t', 1)
                uid = parts[0].strip()
                password = parts[1].strip()
                
                if uid.isdigit() and len(uid) >= 8:
                    accounts.append({'uid': uid, 'password': password, 'name': None})
            
            elif ' ' in line and not any(x in line for x in [':', '|', ',', '\t']):
                parts = line.split(' ', 1)
                uid = parts[0].strip()
                password = parts[1].strip()
                
                if uid.isdigit() and len(uid) >= 8:
                    accounts.append({'uid': uid, 'password': password, 'name': None})
    
    except Exception as e:
        print(f"Error reading file: {e}")
    
    return accounts

def LoAd_AcCoUnTs_FrOm_PaTh(path):
    all_accounts = []
    
    if os.path.isfile(path):
        print(f"\n📄 Loading file: {path}")
        
        if path.lower().endswith('.json'):
            accounts = LoAd_AcCoUnTs_FrOm_JSoN(path)
        else:
            accounts = DeTeCt_FiLe_FoRmAt(path)
        
        all_accounts.extend(accounts)
        print(f"   Found {len(accounts)} accounts")
    
    elif os.path.isdir(path):
        print(f"\n📁 Scanning directory: {path}")
        
        patterns = ['*.txt', '*.csv', '*.log', '*.data', '*.json']
        
        for pattern in patterns:
            files = glob.glob(os.path.join(path, pattern))
            for file in files:
                if os.path.isfile(file):
                    print(f"   Reading: {os.path.basename(file)}")
                    
                    if file.lower().endswith('.json'):
                        accounts = LoAd_AcCoUnTs_FrOm_JSoN(file)
                    else:
                        accounts = DeTeCt_FiLe_FoRmAt(file)
                    
                    if accounts:
                        print(f"   Found {len(accounts)} accounts in {os.path.basename(file)}")
                        all_accounts.extend(accounts)
    
    else:
        print(f"\n❌ Path not found: {path}")
    
    return all_accounts

def ClEaR_ScReEn():
    os.system('cls' if os.name == 'nt' else 'clear')

def PrInT_BaNnEr():
    banner = """
    ╔══════════════════════════════════════════════════════════════════╗
    ║     🔥 FREEFIRE BATCH BIO UPLOADER - PARALLEL EDITION 🔥         ║
    ║                                                                  ║
    ║     🚀 50 Accounts Simultaneously!                               ║
    ║     Supports: JSON, TXT, CSV, LOG, DATA                          ║
    ║     Formats: UID:PASS, UID|PASS, JSON array/object               ║
    ╚══════════════════════════════════════════════════════════════════╝
    """
    print(banner)

def PrInT_ReSuLt_SuMmArY(results, bio, elapsed_time):
    print("\n" + "="*70)
    print("📊 BATCH UPLOAD SUMMARY")
    print("="*70)
    print(f"📝 Bio: {bio}")
    print(f"👥 Total Accounts: {len(results)}")
    print(f"⏱️  Time taken: {elapsed_time:.2f} seconds")
    
    success = [r for r in results if r.get('status') == "✅ Success"]
    failed = [r for r in results if r.get('status') != "✅ Success"]
    
    print(f"✅ Success: {len(success)}")
    print(f"❌ Failed: {len(failed)}")
    
    if len(success) > 0:
        success_rate = (len(success) / len(results)) * 100
        print(f"📈 Success Rate: {success_rate:.1f}%")
    
    print("="*70)
    
    if success:
        print("\n✅ SUCCESSFUL ACCOUNTS (First 20):")
        for r in success[:20]:
            name_display = r.get('name', 'N/A') if r.get('name') else 'N/A'
            print(f"   🆔 {r['uid']} | 👤 {name_display} | 🌍 {r.get('region', 'N/A')}")
        if len(success) > 20:
            print(f"   ... and {len(success) - 20} more")
    
    if failed:
        print("\n❌ FAILED ACCOUNTS:")
        for r in failed[:20]:
            name_display = r.get('name', 'N/A') if r.get('name') else 'N/A'
            print(f"   🆔 {r['uid']} | 👤 {name_display} | Status: {r.get('status', 'Unknown')}")
        if len(failed) > 20:
            print(f"   ... and {len(failed) - 20} more")
    
    print("\n" + "="*70)

def MaIn():
    while True:
        ClEaR_ScReEn()
        PrInT_BaNnEr()
        
        print("\n" + "="*70)
        print("OPTIONS:")
        print("="*70)
        print("  [1] Upload bio to all accounts from FILE (Parallel)")
        print("  [2] Upload bio to all accounts from FOLDER (Parallel)")
        print("  [3] Set parallel threads (Default: 50)")
        print("  [4] Exit")
        print("="*70)
        
        max_workers = 50
        
        choice = input("\n👉 Enter your choice (1-4): ").strip()
        
        if choice == '1':
            filepath = input("\n📂 Enter file path (e.g., accounts.json): ").strip()
            
            if not os.path.exists(filepath):
                input("\n❌ File not found! Press Enter to continue...")
                continue
            
            bio = input("\n📝 Enter bio to upload: ").strip()
            if not bio:
                input("\n⚠️ Bio required! Press Enter to continue...")
                continue
            
            accounts = LoAd_AcCoUnTs_FrOm_PaTh(filepath)
            
            if not accounts:
                input("\n❌ No valid accounts found in file! Press Enter to continue...")
                continue
            
            print(f"\n📊 Total accounts found: {len(accounts)}")
            
            for acc in accounts[:5]:
                print(f"   🆔 {acc['uid']} | 👤 {acc.get('name', 'N/A')}")
            if len(accounts) > 5:
                print(f"   ... and {len(accounts) - 5} more")
            
            confirm = input(f"\n⚠️ Upload bio to {len(accounts)} accounts with {max_workers} parallel threads? (y/n): ").strip().lower()
            
            if confirm == 'y':
                print("\n⏳ Starting parallel batch upload...\n")
                start_time = time.time()
                results = PaRalLeL_Batch_UpLoAd(accounts, bio, max_workers)
                elapsed_time = time.time() - start_time
                PrInT_ReSuLt_SuMmArY(results, bio, elapsed_time)
            else:
                print("\n❌ Cancelled!")
            
            input("\nPress Enter to continue...")
            
        elif choice == '2':
            folderpath = input("\n📁 Enter folder path: ").strip()
            
            if not os.path.exists(folderpath):
                input("\n❌ Folder not found! Press Enter to continue...")
                continue
            
            bio = input("\n📝 Enter bio to upload: ").strip()
            if not bio:
                input("\n⚠️ Bio required! Press Enter to continue...")
                continue
            
            accounts = LoAd_AcCoUnTs_FrOm_PaTh(folderpath)
            
            if not accounts:
                input("\n❌ No valid accounts found in folder! Press Enter to continue...")
                continue
            
            print(f"\n📊 Total accounts found: {len(accounts)}")
            
            for acc in accounts[:5]:
                print(f"   🆔 {acc['uid']} | 👤 {acc.get('name', 'N/A')}")
            if len(accounts) > 5:
                print(f"   ... and {len(accounts) - 5} more")
            
            confirm = input(f"\n⚠️ Upload bio to {len(accounts)} accounts with {max_workers} parallel threads? (y/n): ").strip().lower()
            
            if confirm == 'y':
                print("\n⏳ Starting parallel batch upload...\n")
                start_time = time.time()
                results = PaRalLeL_Batch_UpLoAd(accounts, bio, max_workers)
                elapsed_time = time.time() - start_time
                PrInT_ReSuLt_SuMmArY(results, bio, elapsed_time)
            else:
                print("\n❌ Cancelled!")
            
            input("\nPress Enter to continue...")
            
        elif choice == '3':
            try:
                new_workers = int(input("\n🔧 Enter number of parallel threads (1-200): ").strip())
                if 1 <= new_workers <= 200:
                    max_workers = new_workers
                    print(f"\n✅ Parallel threads set to {max_workers}")
                else:
                    print("\n❌ Please enter value between 1 and 200")
            except:
                print("\n❌ Invalid input!")
            time.sleep(1)
            
        elif choice == '4':
            print("\n👋 Goodbye!")
            sys.exit(0)
            
        else:
            input("\n❌ Invalid choice! Press Enter to continue...")

if __name__ == "__main__":
    MaIn()