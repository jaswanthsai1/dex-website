import json, base64, hashlib, socket
import requests, urllib3
from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
import DaNgEr_MajoRLogin_pb2 as mLpB
import MajorLoginRes_pb2 as mLrPb
import GetLoginDataRes_pb2 as gLdPb

urllib3.disable_warnings()
app = Flask(__name__)

cK     = hashlib.md5(b"\x40\x53\x5f\x30\x5f\x33\x5f\x30").hexdigest()
AeSkEy = b'Yg&tc%DEuh6%Zc^8'
AeSiV  = b'6oyZDr22E3ychjM%'
mLuRl  = "https://loginbp.ggpolarbear.com/MajorLogin"
gLuRl  = "https://clientbp.ggpolarbear.com/GetLoginData"
iNuRl  = "https://100067.connect.garena.com/oauth/token/inspect?token={t}"
mLhDr  = {"User-Agent":"Dalvik/2.1.0 (Linux; U; Android 11; SM-S908E Build/TP1A.220624.014)","Connection":"Keep-Alive","Accept-Encoding":"gzip","Content-Type":"application/octet-stream","Expect":"100-continue","X-GA":"v1 1","X-Unity-Version":"2018.4.11f1","ReleaseVersion":"OB52"}
iNhDr  = {"Accept-Encoding":"gzip, deflate, br","Connection":"close","Content-Type":"application/x-www-form-urlencoded","Host":"100067.connect.garena.com","User-Agent":"GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)"}

def enc(d): return AES.new(AeSkEy,AES.MODE_CBC,AeSiV).encrypt(pad(d,16))
def dec(d): return unpad(AES.new(AeSkEy,AES.MODE_CBC,AeSiV).decrypt(d),16)

def jwtPay(s):
    p=s.split('.')[1]; r=len(p)%4
    return json.loads(base64.urlsafe_b64decode(p+'='*(4-r if r else 0)))

def bUiLd(oId,tok):
    m=mLpB.MajorLogin()
    m.event_time              = str(datetime.now())[:-7]
    m.game_name               = "free fire"
    m.platform_id             = 1
    m.client_version          = "1.120.1"
    m.system_software         = "Android OS 9 / API-28 (PQ3B.190801.10101846/G9650ZHU2ARC6)"
    m.system_hardware         = "Handheld"
    m.telecom_operator        = "Verizon"
    m.network_type            = "WIFI"
    m.screen_width            = 1920
    m.screen_height           = 1080
    m.screen_dpi              = "280"
    m.processor_details       = "ARM64 FP ASIMD AES VMH | 2865 | 4"
    m.memory                  = 3003
    m.gpu_renderer            = "Adreno (TM) 640"
    m.gpu_version             = "OpenGL ES 3.1 v1.46"
    m.unique_device_id        = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
    m.client_ip               = "223.191.51.89"
    m.language                = "en"
    m.open_id                 = oId
    m.open_id_type            = "4"
    m.device_type             = "Handheld"
    m.memory_available.version     = 55
    m.memory_available.hidden_value= 81
    m.access_token            = tok
    m.platform_sdk_id         = 1
    m.network_operator_a      = "Verizon"
    m.network_type_a          = "WIFI"
    m.client_using_version    = "7428b253defc164018c604a1ebbfebdf"
    m.external_storage_total  = 36235
    m.external_storage_available = 31335
    m.internal_storage_total  = 2519
    m.internal_storage_available = 703
    m.game_disk_storage_available= 25010
    m.game_disk_storage_total = 26628
    m.external_sdcard_avail_storage = 32992
    m.external_sdcard_total_storage = 36235
    m.login_by                = 3
    m.library_path            = "/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/lib/arm64"
    m.reg_avatar              = 1
    m.library_token           = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/base.apk"
    m.channel_type            = 3
    m.cpu_type                = 2
    m.cpu_architecture        = "64"
    m.client_version_code     = "2019118695"
    m.graphics_api            = "OpenGLES2"
    m.supported_astc_bitset   = 16383
    m.login_open_id_type      = 4
    m.analytics_detail        = b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg=="
    m.loading_time            = 13564
    m.release_channel         = "android"
    m.extra_info              = "KqsHTymw5/5GB23YGniUYN2/q47GATrq7eFeRatf0NkwLKEMQ0PK5BKEk72dPflAxUlEBir6Vtey83XqF593qsl8hwY="
    m.android_engine_init_flag= 110009
    m.if_push                 = 1
    m.is_vpn                  = 1
    m.origin_platform_type    = "4"
    m.primary_platform_type   = "4"
    return enc(m.SerializeToString())

def pKt(aId,ts,jwt,k,iv):
    e=AES.new(k,AES.MODE_CBC,iv).encrypt(pad(jwt.encode(),16)).hex()
    hx=hex(int(aId))[2:]
    h=f"0115{'0'*(16-len(hx))}{hx}{hex(ts)[2:].zfill(2)}00000{hex(len(e)//2)[2:]}"
    return bytes.fromhex(h+e)

def tcpSnd(ip,port,pkt):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.settimeout(6)
    try:
        s.connect((ip,int(port)))
        s.sendall(pkt)
        r=[]
        try:
            while True:
                c=s.recv(4096)
                if not c: break
                r.append(c)
        except: pass
        return b"".join(r)
    finally: s.close()

def vCr(d): return hashlib.md5(d.get("Dev","").encode().replace(b"@",b"\x40")).hexdigest()==cK

def run(tok):
    r=requests.get(iNuRl.format(t=tok),headers=iNhDr,timeout=10).json()
    if 'error' in r: return {"success":False,"error":r.get('error'),"Dev":"@S_0_3_0"}
    oId,plat=r['open_id'],r['platform']
    pl=bUiLd(oId,tok)

    x=requests.post(mLuRl,headers=mLhDr,data=pl,timeout=15,verify=False)
    if not x.ok: return {"success":False,"error":f"MajorLogin {x.status_code}","Dev":"@S_0_3_0"}
    res=mLrPb.MajorLoginRes()
    try:    res.ParseFromString(dec(x.content))
    except: res.ParseFromString(x.content)
    if not res.account_jwt: return {"success":False,"error":"empty jwt","Dev":"@S_0_3_0"}

    cl=jwtPay(res.account_jwt)
    ts=Timestamp(); ts.FromNanoseconds(int(cl.get("exp",0))*1_000_000_000)
    tNs=ts.seconds*1_000_000_000+ts.nanos

    gH={"Expect":"100-continue","Authorization":f"Bearer {res.account_jwt}","X-Unity-Version":"2018.4.11f1","X-GA":"v1 1","ReleaseVersion":"OB52","Content-Type":"application/x-www-form-urlencoded","User-Agent":"Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)","Host":"clientbp.ggpolarbear.com","Connection":"close","Accept-Encoding":"gzip, deflate, br"}
    r2=requests.post(gLuRl,headers=gH,data=pl,timeout=12,verify=False)
    if r2.status_code!=200: return {"success":False,"error":f"GetLoginData {r2.status_code}","Dev":"@S_0_3_0"}

    g=gLdPb.GetLoginDataRes()
    try:    g.ParseFromString(dec(r2.content))
    except: g.ParseFromString(r2.content)
    if not g.ip_port_online: return {"success":False,"error":"ip_port_online empty","Dev":"@S_0_3_0"}

    ip,prt=g.ip_port_online.rsplit(":",1)
    aId=int(cl.get("account_id",res.account_id))
    pkt=pKt(aId,tNs,res.account_jwt,res.key,res.iv)
    tcpSnd(ip,prt,pkt)

    return {
        "success"   : True,
        "account_id": aId,
        "open_id"   : oId,
        "platform"  : plat,
        "jwt"       : res.account_jwt,
        "payload"   : cl,
        "Dev"       : "@S_0_3_0"
    }

@app.get("/login")
def ep():
    tok=request.args.get("access","").strip()
    if not tok: return jsonify({"success":False,"error":"missing access token","Dev":"@S_0_3_0"}),400
    out=run(tok)
    if not vCr(out): return jsonify({"error":"ازبي رجع الاسم تع الكريديت","Dev":"@S_0_3_0"}),403
    return jsonify(out)

if __name__=="__main__": app.run(host="0.0.0.0",port=5000,debug=False)
