import logging
import asyncio
from datetime import datetime, timedelta
from typing import Optional, Dict, List
import re
import sqlite3
from contextlib import contextmanager
from collections import defaultdict

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatMember, Chat, BotCommand
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ChatMemberHandler,
    filters,
    ContextTypes,
    ConversationHandler
)
from telegram.constants import ChatMemberStatus, ParseMode
from telegram.error import TelegramError

# ==================== CONFIGURATION ====================
BOT_TOKEN = "8232241507:AAFGxXfKNxuG7firY0R3zvaCpaGZbTAiwiI"  # Replace with your bot token
ADMIN_IDS = [7705767559]  # Replace with your Telegram user ID

# ==================== DATABASE SETUP ====================
class Database:
    def __init__(self, db_name="group_bot.db"):
        self.db_name = db_name
        self.init_db()

    @contextmanager
    def get_connection(self):
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Groups table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS groups (
                    group_id INTEGER PRIMARY KEY,
                    group_name TEXT,
                    welcome_message TEXT DEFAULT 'Welcome {name} to {group}!',
                    rules TEXT,
                    anti_spam BOOLEAN DEFAULT 1,
                    anti_link BOOLEAN DEFAULT 0,
                    anti_arabic BOOLEAN DEFAULT 0,
                    anti_english BOOLEAN DEFAULT 0,
                    captcha_enabled BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Banned users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS banned_users (
                    user_id INTEGER,
                    group_id INTEGER,
                    banned_by INTEGER,
                    reason TEXT,
                    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, group_id)
                )
            ''')
            
            # Warnings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS warnings (
                    user_id INTEGER,
                    group_id INTEGER,
                    warned_by INTEGER,
                    reason TEXT,
                    warned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Filters table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS filters (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    group_id INTEGER,
                    trigger_word TEXT,
                    response_text TEXT,
                    created_by INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(group_id, trigger_word)
                )
            ''')
            
            # Settings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS settings (
                    group_id INTEGER PRIMARY KEY,
                    language TEXT DEFAULT 'en',
                    delete_commands BOOLEAN DEFAULT 1,
                    welcome_enabled BOOLEAN DEFAULT 1,
                    goodbye_enabled BOOLEAN DEFAULT 1,
                    auto_delete_time INTEGER DEFAULT 0
                )
            ''')
            
            conn.commit()

db = Database()

# ==================== GROUP MANAGER CLASS ====================
class GroupManager:
    def __init__(self):
        self.welcome_tasks = {}
        self.user_messages = defaultdict(list)
        
    async def is_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
        """Check if user is admin in the group"""
        try:
            user_id = update.effective_user.id
            chat_id = update.effective_chat.id
            
            if user_id in ADMIN_IDS:
                return True
                
            chat_member = await context.bot.get_chat_member(chat_id, user_id)
            return chat_member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]
        except:
            return False
    
    async def is_creator(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
        """Check if user is group creator"""
        try:
            user_id = update.effective_user.id
            chat_id = update.effective_chat.id
            chat_member = await context.bot.get_chat_member(chat_id, user_id)
            return chat_member.status == ChatMemberStatus.OWNER
        except:
            return False

manager = GroupManager()

# ==================== UTILITY FUNCTIONS ====================
def escape_markdown(text: str) -> str:
    """Escape markdown special characters"""
    special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text

async def delete_message_after_delay(context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_id: int, delay: int = 5):
    """Delete a message after specified delay"""
    await asyncio.sleep(delay)
    try:
        await context.bot.delete_message(chat_id, message_id)
    except:
        pass

def get_group_settings(group_id: int) -> Dict:
    """Get group settings from database"""
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM settings WHERE group_id = ?", (group_id,))
        settings = cursor.fetchone()
        
        if not settings:
            cursor.execute("INSERT INTO settings (group_id) VALUES (?)", (group_id,))
            conn.commit()
            return {"language": "en", "delete_commands": 1, "welcome_enabled": 1, "goodbye_enabled": 1, "auto_delete_time": 0}
        
        return dict(settings)

# ==================== CONVERSATION STATES ====================
(SET_WELCOME, SET_RULES, ADD_FILTER, SETTINGS_MENU) = range(4)

# ==================== COMMAND HANDLERS ====================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command handler"""
    if update.effective_chat.type != "private":
        return
    
    user = update.effective_user
    welcome_text = f"""
🌟 *Welcome to Group Management Bot* 🌟

Hello {user.first_name}! I'm a powerful group management bot designed to help you manage your Telegram groups efficiently.

📌 *Commands:*
• /start - Show this message
• /help - Get detailed help
• /addgroup - Add bot to your group

🔧 *Admin Commands (in groups):*
• /settings - Configure group settings
• /welcome - Set welcome message
• /rules - Set group rules
• /filter - Add auto-response filters
• /filters - List all filters
• /removefilter - Remove a filter
• /ban - Ban a user
• /unban - Unban a user
• /kick - Kick a user
• /warn - Warn a user
• /warnings - Check user warnings
• /resetwarns - Reset warnings
• /mute - Mute a user
• /unmute - Unmute a user
• /pin - Pin a message
• /unpin - Unpin message
• /purge - Delete multiple messages
• /lock - Lock group features
• /unlock - Unlock group features

Add me to your group and make me admin to start managing!
    """
    
    keyboard = [
        [InlineKeyboardButton("➕ Add to Group", url=f"https://t.me/{context.bot.username}?startgroup=true")],
        [InlineKeyboardButton("📢 Support Channel", url="https://t.me/ARAFAT_CODEX11")],
        [InlineKeyboardButton("📚 Documentation", url="https://t.me/mahfuj_offcial")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=reply_markup,
        disable_web_page_preview=True
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Help command handler"""
    if update.effective_chat.type == "private":
        await start_command(update, context)
        return
    
    help_text = """
🤖 *Group Management Bot Help*

*Basic Commands:*
• /help - Show this help message
• /admin - Show admin commands
• /rules - Show group rules
• /info - Show user info
• /id - Show chat/user ID

*Admin Commands:*
• /settings - Configure bot settings
• /welcome [message] - Set welcome message
• /rules [text] - Set group rules
• /filter [word] [response] - Add auto-filter
• /filters - List all filters
• /removefilter [word] - Remove filter
• /ban [reply/username] - Ban user
• /unban [username] - Unban user
• /kick [reply/username] - Kick user
• /mute [time] - Mute user
• /unmute - Unmute user
• /warn [reason] - Warn user
• /warnings [user] - Check warnings
• /resetwarns [user] - Reset warnings
• /pin [text] - Pin message
• /unpin - Unpin last pinned
• /purge [count] - Delete messages
• /lock [feature] - Lock feature
• /unlock [feature] - Unlock feature

*Features:*
✅ Anti-spam protection
✅ Anti-link filtering
✅ Welcome/Goodbye messages
✅ Auto-moderation
✅ Custom filters
✅ Warning system
✅ Captcha verification
✅ Message purging
✅ And much more...

*How to use:*
1. Make me admin in your group
2. Use /settings to configure
3. Start managing your group!

Need more help? Contact @arafat_codex1
    """
    
    await update.message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin commands"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    admin_text = """
👑 *Admin Commands*

*Group Management:*
• /settings - Configure bot settings
• /welcome [message] - Set welcome message
• /rules [text] - Set group rules
• /filter [word] [response] - Add auto-filter
• /filters - List all filters
• /removefilter [word] - Remove filter

*User Management:*
• /ban [user] [reason] - Ban user
• /unban [user] - Unban user
• /kick [user] [reason] - Kick user
• /mute [time] - Mute user
• /unmute [user] - Unmute user
• /warn [user] [reason] - Warn user
• /warnings [user] - Check warnings
• /resetwarns [user] - Reset warnings

*Message Management:*
• /pin [message] - Pin message
• /unpin - Unpin message
• /purge [count] - Delete messages

*Security:*
• /lock [feature] - Lock group feature
• /unlock [feature] - Unlock feature
• /antispam [on/off] - Toggle anti-spam
• /antilink [on/off] - Toggle anti-link
• /captcha [on/off] - Toggle captcha

*Available features to lock:*
• messages - Send messages
• media - Send photos/videos
• stickers - Send stickers
• polls - Create polls
• info - Change group info
• invites - Send invites
• pins - Pin messages
    """
    
    await update.message.reply_text(admin_text, parse_mode=ParseMode.MARKDOWN)

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Settings menu"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    settings = get_group_settings(chat.id)
    
    keyboard = [
        [InlineKeyboardButton("📝 Welcome Message", callback_data="set_welcome")],
        [InlineKeyboardButton("📜 Group Rules", callback_data="set_rules")],
        [InlineKeyboardButton("🛡️ Anti-Spam", callback_data="toggle_antispam")],
        [InlineKeyboardButton("🔗 Anti-Link", callback_data="toggle_antilink")],
        [InlineKeyboardButton("🔢 Captcha Verification", callback_data="toggle_captcha")],
        [InlineKeyboardButton("🗑️ Auto-Delete Commands", callback_data="toggle_autodelete")],
        [InlineKeyboardButton("👋 Welcome Messages", callback_data="toggle_welcome")],
        [InlineKeyboardButton("👋 Goodbye Messages", callback_data="toggle_goodbye")],
        [InlineKeyboardButton("🌐 Language", callback_data="language")],
        [InlineKeyboardButton("❌ Close", callback_data="close_settings")]
    ]
    
    status = {
        "antispam": "✅ Enabled" if settings.get("antispam", 1) else "❌ Disabled",
        "antilink": "✅ Enabled" if settings.get("antilink", 0) else "❌ Disabled",
        "captcha": "✅ Enabled" if settings.get("captcha_enabled", 0) else "❌ Disabled",
        "autodelete": "✅ Enabled" if settings.get("delete_commands", 1) else "❌ Disabled",
        "welcome": "✅ Enabled" if settings.get("welcome_enabled", 1) else "❌ Disabled",
        "goodbye": "✅ Enabled" if settings.get("goodbye_enabled", 1) else "❌ Disabled"
    }
    
    settings_text = f"""
⚙️ *Group Settings for {chat.title}*

*Current Configuration:*
• Anti-Spam: {status['antispam']}
• Anti-Link: {status['antilink']}
• Captcha: {status['captcha']}
• Auto-Delete Commands: {status['autodelete']}
• Welcome Messages: {status['welcome']}
• Goodbye Messages: {status['goodbye']}

Select an option to configure:
    """
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(settings_text, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)

async def rules_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show group rules"""
    chat = update.effective_chat
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT rules FROM groups WHERE group_id = ?", (chat.id,))
        result = cursor.fetchone()
    
    if result and result['rules']:
        rules_text = f"📜 *Group Rules*\n\n{result['rules']}"
    else:
        rules_text = "📜 No rules have been set for this group yet.\nAdmins can use /rules [text] to set rules."
    
    await update.message.reply_text(rules_text, parse_mode=ParseMode.MARKDOWN)

async def set_rules_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set group rules (admin only)"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /rules [rules text]")
        return
    
    chat = update.effective_chat
    rules_text = ' '.join(context.args)
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO groups (group_id, group_name, rules) VALUES (?, ?, ?)",
            (chat.id, chat.title, rules_text)
        )
        conn.commit()
    
    await update.message.reply_text("✅ Group rules have been updated successfully!")

async def welcome_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set welcome message"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text(
            "Usage: /welcome [message]\n\n"
            "Available variables:\n"
            "{name} - User's first name\n"
            "{username} - User's username\n"
            "{group} - Group name\n"
            "{count} - Member count\n\n"
            "Example: /welcome Welcome {name} to {group}! You are member #{count}"
        )
        return
    
    chat = update.effective_chat
    welcome_msg = ' '.join(context.args)
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO groups (group_id, group_name, welcome_message) VALUES (?, ?, ?)",
            (chat.id, chat.title, welcome_msg)
        )
        conn.commit()
    
    await update.message.reply_text("✅ Welcome message has been updated!")

async def filter_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add auto-response filter"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /filter [trigger word] [response text]")
        return
    
    chat = update.effective_chat
    trigger = context.args[0].lower()
    response = ' '.join(context.args[1:])
    
    try:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO filters (group_id, trigger_word, response_text, created_by) VALUES (?, ?, ?, ?)",
                (chat.id, trigger, response, update.effective_user.id)
            )
            conn.commit()
        
        await update.message.reply_text(f"✅ Filter added: When someone says '{trigger}', I'll respond with the specified message.")
    except sqlite3.IntegrityError:
        await update.message.reply_text("❌ This filter already exists. Use /removefilter first to update it.")

async def filters_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all filters"""
    chat = update.effective_chat
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT trigger_word, response_text FROM filters WHERE group_id = ? ORDER BY trigger_word",
            (chat.id,)
        )
        filters_list = cursor.fetchall()
    
    if not filters_list:
        await update.message.reply_text("No filters have been set in this group.")
        return
    
    filter_text = "📋 *Group Filters*\n\n"
    for i, filter_item in enumerate(filters_list, 1):
        filter_text += f"{i}. `{filter_item['trigger_word']}` → {filter_item['response_text'][:50]}\n"
    
    await update.message.reply_text(filter_text, parse_mode=ParseMode.MARKDOWN)

async def removefilter_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove a filter"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /removefilter [trigger word]")
        return
    
    chat = update.effective_chat
    trigger = context.args[0].lower()
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM filters WHERE group_id = ? AND trigger_word = ?",
            (chat.id, trigger)
        )
        conn.commit()
        
        if cursor.rowcount > 0:
            await update.message.reply_text(f"✅ Filter '{trigger}' has been removed.")
        else:
            await update.message.reply_text(f"❌ No filter found with trigger '{trigger}'.")

async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban a user"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not context.args and not update.message.reply_to_message:
        await update.message.reply_text("Usage: /ban [user_id/username] or reply to a user's message")
        return
    
    user_id = None
    user_name = "User"
    
    if update.message.reply_to_message:
        user_id = update.message.reply_to_message.from_user.id
        user_name = update.message.reply_to_message.from_user.first_name
        reason = ' '.join(context.args) if context.args else "No reason provided"
    else:
        # Try to parse user_id or username
        target = context.args[0]
        reason = ' '.join(context.args[1:]) if len(context.args) > 1 else "No reason provided"
        
        # Check if it's a user_id
        if target.lstrip('-').isdigit():
            user_id = int(target)
        else:
            # Try to get user from username
            username = target.lstrip('@')
            try:
                # This is not directly possible, would need to search member list
                await update.message.reply_text("❌ Please use user ID or reply to a user's message.")
                return
            except:
                await update.message.reply_text("❌ Invalid user specified.")
                return
    
    if user_id == update.effective_user.id:
        await update.message.reply_text("❌ You cannot ban yourself.")
        return
    
    try:
        await context.bot.ban_chat_member(chat.id, user_id)
        
        # Record in database
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO banned_users (user_id, group_id, banned_by, reason) VALUES (?, ?, ?, ?)",
                (user_id, chat.id, update.effective_user.id, reason)
            )
            conn.commit()
        
        await update.message.reply_text(f"✅ {user_name} has been banned.\nReason: {reason}")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to ban user: {str(e)}")

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unban a user"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not context.args:
        await update.message.reply_text("Usage: /unban [user_id]")
        return
    
    try:
        user_id = int(context.args[0])
        
        await context.bot.unban_chat_member(chat.id, user_id)
        
        # Remove from database
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM banned_users WHERE user_id = ? AND group_id = ?",
                (user_id, chat.id)
            )
            conn.commit()
        
        await update.message.reply_text(f"✅ User {user_id} has been unbanned.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to unban user: {str(e)}")

async def kick_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Kick a user (ban and then unban)"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not context.args and not update.message.reply_to_message:
        await update.message.reply_text("Usage: /kick [user] or reply to a user's message")
        return
    
    user_id = None
    user_name = "User"
    
    if update.message.reply_to_message:
        user_id = update.message.reply_to_message.from_user.id
        user_name = update.message.reply_to_message.from_user.first_name
        reason = ' '.join(context.args) if context.args else "No reason provided"
    else:
        # Similar logic as ban command
        await update.message.reply_text("Please reply to a user's message to kick them.")
        return
    
    if user_id == update.effective_user.id:
        await update.message.reply_text("❌ You cannot kick yourself.")
        return
    
    try:
        # Ban and then unban to kick
        await context.bot.ban_chat_member(chat.id, user_id)
        await context.bot.unban_chat_member(chat.id, user_id)
        
        await update.message.reply_text(f"✅ {user_name} has been kicked.\nReason: {reason}")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to kick user: {str(e)}")

async def warn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Warn a user"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a user's message with /warn [reason]")
        return
    
    warned_user = update.message.reply_to_message.from_user
    reason = ' '.join(context.args) if context.args else "No reason provided"
    
    # Record warning
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO warnings (user_id, group_id, warned_by, reason) VALUES (?, ?, ?, ?)",
            (warned_user.id, chat.id, update.effective_user.id, reason)
        )
        
        # Count warnings
        cursor.execute(
            "SELECT COUNT(*) as count FROM warnings WHERE user_id = ? AND group_id = ?",
            (warned_user.id, chat.id)
        )
        warning_count = cursor.fetchone()['count']
        conn.commit()
    
    # Auto-ban after 3 warnings
    if warning_count >= 3:
        try:
            await context.bot.ban_chat_member(chat.id, warned_user.id)
            await update.message.reply_text(f"⚠️ {warned_user.first_name} has been banned for exceeding 3 warnings.")
        except:
            pass
    
    await update.message.reply_text(
        f"⚠️ {warned_user.first_name} has been warned.\n"
        f"Reason: {reason}\n"
        f"Warnings: {warning_count}/3"
    )

async def warnings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check user warnings"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if update.message.reply_to_message:
        user = update.message.reply_to_message.from_user
    elif context.args:
        # Try to parse user_id
        try:
            user_id = int(context.args[0])
            # Would need to get user info
            await update.message.reply_text("Please reply to a user's message to check their warnings.")
            return
        except:
            await update.message.reply_text("Usage: /warnings (reply to a user)")
            return
    else:
        await update.message.reply_text("Usage: /warnings (reply to a user)")
        return
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT reason, warned_at FROM warnings WHERE user_id = ? AND group_id = ? ORDER BY warned_at DESC",
            (user.id, chat.id)
        )
        warnings_list = cursor.fetchall()
        
        cursor.execute(
            "SELECT COUNT(*) as count FROM warnings WHERE user_id = ? AND group_id = ?",
            (user.id, chat.id)
        )
        count = cursor.fetchone()['count']
    
    if not warnings_list:
        await update.message.reply_text(f"✅ {user.first_name} has no warnings.")
        return
    
    warnings_text = f"⚠️ *Warnings for {user.first_name}*\nTotal: {count}/3\n\n"
    for i, warning in enumerate(warnings_list, 1):
        date = datetime.fromisoformat(warning['warned_at']).strftime("%Y-%m-%d %H:%M")
        warnings_text += f"{i}. {warning['reason']} - {date}\n"
    
    await update.message.reply_text(warnings_text, parse_mode=ParseMode.MARKDOWN)

async def resetwarns_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reset user warnings"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a user's message with /resetwarns")
        return
    
    user = update.message.reply_to_message.from_user
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM warnings WHERE user_id = ? AND group_id = ?",
            (user.id, chat.id)
        )
        conn.commit()
    
    await update.message.reply_text(f"✅ Warnings for {user.first_name} have been reset.")

async def mute_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute a user"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a user's message with /mute [time in minutes]")
        return
    
    user = update.message.reply_to_message.from_user
    
    # Parse time
    mute_time = None
    if context.args:
        try:
            mute_time = int(context.args[0])
        except:
            pass
    
    permissions = ChatMember(can_send_messages=False)
    
    try:
        until_date = None
        if mute_time:
            until_date = datetime.now() + timedelta(minutes=mute_time)
        
        await context.bot.restrict_chat_member(
            chat.id,
            user.id,
            permissions,
            until_date=until_date
        )
        
        time_text = f" for {mute_time} minutes" if mute_time else ""
        await update.message.reply_text(f"🔇 {user.first_name} has been muted{time_text}.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to mute user: {str(e)}")

async def unmute_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute a user"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a user's message with /unmute")
        return
    
    user = update.message.reply_to_message.from_user
    
    permissions = ChatMember(
        can_send_messages=True,
        can_send_media_messages=True,
        can_send_polls=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True
    )
    
    try:
        await context.bot.restrict_chat_member(chat.id, user.id, permissions)
        await update.message.reply_text(f"🔊 {user.first_name} has been unmuted.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to unmute user: {str(e)}")

async def pin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pin a message"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a message with /pin")
        return
    
    try:
        await context.bot.pin_chat_message(
            chat_id=update.effective_chat.id,
            message_id=update.message.reply_to_message.message_id,
            disable_notification=False
        )
        await update.message.reply_text("📌 Message pinned successfully!")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to pin message: {str(e)}")

async def unpin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unpin message"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    try:
        await context.bot.unpin_chat_message(chat_id=update.effective_chat.id)
        await update.message.reply_text("📌 Last pinned message has been unpinned.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to unpin message: {str(e)}")

async def purge_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete multiple messages"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    chat = update.effective_chat
    
    if not context.args:
        await update.message.reply_text("Usage: /purge [number of messages] (reply to a message to start from there)")
        return
    
    try:
        count = int(context.args[0]) + 1  # +1 to include command message
        if count < 2 or count > 100:
            await update.message.reply_text("Please specify a number between 1 and 99.")
            return
        
        if update.message.reply_to_message:
            start_id = update.message.reply_to_message.message_id
        else:
            start_id = update.message.message_id
        
        message_ids = []
        for msg_id in range(start_id, start_id + count):
            message_ids.append(msg_id)
        
        # Delete in chunks of 100 (Telegram limit)
        for i in range(0, len(message_ids), 100):
            chunk = message_ids[i:i+100]
            await context.bot.delete_messages(chat.id, chunk)
        
        # Send confirmation that will be auto-deleted
        confirm_msg = await update.message.reply_text(f"✅ {count-1} messages have been deleted.")
        asyncio.create_task(delete_message_after_delay(context, chat.id, confirm_msg.message_id, 3))
        
    except ValueError:
        await update.message.reply_text("Please provide a valid number.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to delete messages: {str(e)}")

async def lock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lock group features"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text(
            "Usage: /lock [feature]\n\n"
            "Features: messages, media, stickers, polls, info, invites, pins"
        )
        return
    
    chat = update.effective_chat
    feature = context.args[0].lower()
    
    permissions = {
        'messages': {'can_send_messages': False},
        'media': {'can_send_media_messages': False},
        'stickers': {'can_send_other_messages': False},
        'polls': {'can_send_polls': False},
        'info': {'can_change_info': False},
        'invites': {'can_invite_users': False},
        'pins': {'can_pin_messages': False}
    }
    
    if feature not in permissions:
        await update.message.reply_text("❌ Invalid feature. Choose from: " + ', '.join(permissions.keys()))
        return
    
    try:
        # Get current permissions
        current_perms = await context.bot.get_chat(chat.id)
        
        # Update specific permission
        new_perms = ChatMember(
            can_send_messages=current_perms.permissions.can_send_messages if feature != 'messages' else False,
            can_send_media_messages=current_perms.permissions.can_send_media_messages if feature != 'media' else False,
            can_send_polls=current_perms.permissions.can_send_polls if feature != 'polls' else False,
            can_send_other_messages=current_perms.permissions.can_send_other_messages if feature != 'stickers' else False,
            can_add_web_page_previews=current_perms.permissions.can_add_web_page_previews,
            can_change_info=current_perms.permissions.can_change_info if feature != 'info' else False,
            can_invite_users=current_perms.permissions.can_invite_users if feature != 'invites' else False,
            can_pin_messages=current_perms.permissions.can_pin_messages if feature != 'pins' else False
        )
        
        await context.bot.set_chat_permissions(chat.id, new_perms)
        await update.message.reply_text(f"🔒 Feature '{feature}' has been locked.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to lock feature: {str(e)}")

async def unlock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unlock group features"""
    if not await manager.is_admin(update, context):
        await update.message.reply_text("❌ You need to be an admin to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text(
            "Usage: /unlock [feature]\n\n"
            "Features: messages, media, stickers, polls, info, invites, pins"
        )
        return
    
    chat = update.effective_chat
    feature = context.args[0].lower()
    
    permissions = {
        'messages': {'can_send_messages': True},
        'media': {'can_send_media_messages': True},
        'stickers': {'can_send_other_messages': True},
        'polls': {'can_send_polls': True},
        'info': {'can_change_info': True},
        'invites': {'can_invite_users': True},
        'pins': {'can_pin_messages': True}
    }
    
    if feature not in permissions:
        await update.message.reply_text("❌ Invalid feature. Choose from: " + ', '.join(permissions.keys()))
        return
    
    try:
        # Get current permissions
        current_perms = await context.bot.get_chat(chat.id)
        
        # Update specific permission
        new_perms = ChatMember(
            can_send_messages=True if feature == 'messages' else current_perms.permissions.can_send_messages,
            can_send_media_messages=True if feature == 'media' else current_perms.permissions.can_send_media_messages,
            can_send_polls=True if feature == 'polls' else current_perms.permissions.can_send_polls,
            can_send_other_messages=True if feature == 'stickers' else current_perms.permissions.can_send_other_messages,
            can_add_web_page_previews=current_perms.permissions.can_add_web_page_previews,
            can_change_info=True if feature == 'info' else current_perms.permissions.can_change_info,
            can_invite_users=True if feature == 'invites' else current_perms.permissions.can_invite_users,
            can_pin_messages=True if feature == 'pins' else current_perms.permissions.can_pin_messages
        )
        
        await context.bot.set_chat_permissions(chat.id, new_perms)
        await update.message.reply_text(f"🔓 Feature '{feature}' has been unlocked.")
    except TelegramError as e:
        await update.message.reply_text(f"❌ Failed to unlock feature: {str(e)}")

async def id_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user/chat ID"""
    chat = update.effective_chat
    user = update.effective_user
    
    if update.message.reply_to_message:
        target = update.message.reply_to_message.from_user
        text = f"👤 *User Info*\n\nName: {target.first_name}\nID: `{target.id}`"
        if target.username:
            text += f"\nUsername: @{target.username}"
    else:
        text = f"📱 *Chat Info*\n\nTitle: {chat.title}\nChat ID: `{chat.id}`\n\n👤 Your ID: `{user.id}`"
    
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def info_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user information"""
    chat = update.effective_chat
    user = update.effective_user
    
    if update.message.reply_to_message:
        target = update.message.reply_to_message.from_user
        user_id = target.id
    elif context.args and context.args[0].lstrip('@'):
        # Handle username
        username = context.args[0].lstrip('@')
        await update.message.reply_text("Please reply to a user's message to get their info.")
        return
    else:
        target = user
        user_id = user.id
    
    try:
        member = await context.bot.get_chat_member(chat.id, user_id)
        status_emoji = {
            ChatMemberStatus.OWNER: "👑",
            ChatMemberStatus.ADMINISTRATOR: "🔰",
            ChatMemberStatus.MEMBER: "👤",
            ChatMemberStatus.RESTRICTED: "🔇",
            ChatMemberStatus.LEFT: "🚶",
            ChatMemberStatus.BANNED: "🚫"
        }
        
        status = status_emoji.get(member.status, "❓")
        
        info_text = f"""
{status} *User Information*

• Name: {target.first_name} {target.last_name or ''}
• ID: `{target.id}`
• Username: @{target.username if target.username else 'None'}
• Status: {member.status.capitalize()}
"""
        
        if member.status == ChatMemberStatus.RESTRICTED:
            info_text += f"\n• Until: {member.until_date if member.until_date else 'Permanent'}"
        
        await update.message.reply_text(info_text, parse_mode=ParseMode.MARKDOWN)
    except TelegramError:
        await update.message.reply_text("Could not fetch user information.")

# ==================== MESSAGE HANDLERS ====================
async def handle_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle new members joining"""
    chat = update.effective_chat
    
    # Check if bot was added
    for new_member in update.message.new_chat_members:
        if new_member.id == context.bot.id:
            # Bot was added
            await update.message.reply_text(
                "👋 Thanks for adding me! Please make me an admin to use all features.\n"
                "Use /help to see available commands."
            )
            
            # Save group info
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT OR IGNORE INTO groups (group_id, group_name) VALUES (?, ?)",
                    (chat.id, chat.title)
                )
                conn.commit()
            return
    
    # Handle regular members joining
    settings = get_group_settings(chat.id)
    
    if not settings.get('welcome_enabled', 1):
        return
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT welcome_message FROM groups WHERE group_id = ?", (chat.id,))
        result = cursor.fetchone()
    
    if result and result['welcome_message']:
        welcome_msg = result['welcome_message']
    else:
        welcome_msg = "Welcome {name} to {group}!"
    
    # Get member count
    try:
        member_count = await context.bot.get_chat_member_count(chat.id)
    except:
        member_count = "?"
    
    for new_member in update.message.new_chat_members:
        if new_member.is_bot:
            continue
            
        formatted_msg = welcome_msg.format(
            name=new_member.first_name,
            username=f"@{new_member.username}" if new_member.username else new_member.first_name,
            group=chat.title,
            count=member_count
        )
        
        # Check if captcha is enabled
        if settings.get('captcha_enabled', 0):
            # Send captcha
            captcha_text = f"{formatted_msg}\n\nPlease solve this captcha to verify you're human:"
            
            # Generate simple math captcha
            import random
            num1 = random.randint(1, 10)
            num2 = random.randint(1, 10)
            answer = num1 + num2
            
            context.user_data[f'captcha_{new_member.id}'] = answer
            
            keyboard = [[InlineKeyboardButton(f"{num1} + {num2} = ?", callback_data="captcha")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(captcha_text, reply_markup=reply_markup)
            
            # Restrict user until captcha solved
            permissions = ChatMember(can_send_messages=False)
            await context.bot.restrict_chat_member(chat.id, new_member.id, permissions)
        else:
            await update.message.reply_text(formatted_msg)

async def handle_left_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle members leaving"""
    settings = get_group_settings(update.effective_chat.id)
    
    if not settings.get('goodbye_enabled', 1):
        return
    
    for left_member in update.message.left_chat_member:
        if left_member.id == context.bot.id:
            # Bot was removed
            # Clean up database
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM groups WHERE group_id = ?", (update.effective_chat.id,))
                cursor.execute("DELETE FROM settings WHERE group_id = ?", (update.effective_chat.id,))
                cursor.execute("DELETE FROM filters WHERE group_id = ?", (update.effective_chat.id,))
                cursor.execute("DELETE FROM warnings WHERE group_id = ?", (update.effective_chat.id,))
                cursor.execute("DELETE FROM banned_users WHERE group_id = ?", (update.effective_chat.id,))
                conn.commit()
            return
        
        goodbye_msg = f"Goodbye {left_member.first_name}! We'll miss you. 👋"
        await update.message.reply_text(goodbye_msg)

async def handle_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular messages"""
    if not update.message or not update.message.text:
        return
    
    chat = update.effective_chat
    user = update.effective_user
    message_text = update.message.text
    
    # Auto-delete commands if enabled
    settings = get_group_settings(chat.id)
    if settings.get('delete_commands', 1) and message_text.startswith('/'):
        if await manager.is_admin(update, context):
            return
        try:
            await update.message.delete()
        except:
            pass
        return
    
    # Anti-spam check
    if settings.get('antispam', 1):
        # Simple spam detection
        user_id = user.id
        current_time = datetime.now()
        
        # Store message timestamps
        manager.user_messages[user_id].append(current_time)
        
        # Remove old messages
        manager.user_messages[user_id] = [
            t for t in manager.user_messages[user_id] 
            if (current_time - t).seconds < 5
        ]
        
        # Check for spam (more than 5 messages in 5 seconds)
        if len(manager.user_messages[user_id]) > 5:
            if not await manager.is_admin(update, context):
                # Warn and mute
                await context.bot.restrict_chat_member(
                    chat.id,
                    user_id,
                    ChatMember(can_send_messages=False),
                    until_date=datetime.now() + timedelta(minutes=5)
                )
                await update.message.reply_text(
                    f"{user.first_name} has been muted for 5 minutes due to spamming."
                )
                return
    
    # Anti-link check
    if settings.get('antilink', 0):
        # Check for links
        link_pattern = r'(https?://|www\.)[^\s]+'
        if re.search(link_pattern, message_text, re.IGNORECASE):
            if not await manager.is_admin(update, context):
                await update.message.delete()
                warn_msg = await update.message.reply_text(
                    f"{user.first_name}, links are not allowed in this group."
                )
                asyncio.create_task(delete_message_after_delay(context, chat.id, warn_msg.message_id, 5))
                return
    
    # Check filters
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT response_text FROM filters WHERE group_id = ? AND ? LIKE '%' || trigger_word || '%'",
            (chat.id, message_text.lower())
        )
        filters = cursor.fetchall()
    
    for filter_item in filters:
        await update.message.reply_text(filter_item['response_text'])

# ==================== CALLBACK HANDLERS ====================
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "close_settings":
        await query.message.delete()
        return
    
    if data == "set_welcome":
        await query.message.reply_text(
            "Please send the new welcome message.\n"
            "Use variables: {name}, {username}, {group}, {count}\n"
            "Example: Welcome {name} to {group}! You are member #{count}"
        )
        context.user_data['setting'] = 'welcome'
        return
    
    if data == "set_rules":
        await query.message.reply_text("Please send the new group rules.")
        context.user_data['setting'] = 'rules'
        return
    
    if data.startswith("toggle_"):
        feature = data.replace("toggle_", "")
        chat_id = update.effective_chat.id
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            if feature == "antispam":
                cursor.execute("UPDATE settings SET antispam = NOT antispam WHERE group_id = ?", (chat_id,))
            elif feature == "antilink":
                cursor.execute("UPDATE settings SET anti_link = NOT anti_link WHERE group_id = ?", (chat_id,))
            elif feature == "captcha":
                cursor.execute("UPDATE groups SET captcha_enabled = NOT captcha_enabled WHERE group_id = ?", (chat_id,))
            elif feature == "autodelete":
                cursor.execute("UPDATE settings SET delete_commands = NOT delete_commands WHERE group_id = ?", (chat_id,))
            elif feature == "welcome":
                cursor.execute("UPDATE settings SET welcome_enabled = NOT welcome_enabled WHERE group_id = ?", (chat_id,))
            elif feature == "goodbye":
                cursor.execute("UPDATE settings SET goodbye_enabled = NOT goodbye_enabled WHERE group_id = ?", (chat_id,))
            
            conn.commit()
        
        await query.message.reply_text(f"✅ {feature.capitalize()} setting has been toggled.")
        await query.message.delete()
    
    elif data == "language":
        keyboard = [
            [InlineKeyboardButton("English 🇬🇧", callback_data="lang_en")],
            [InlineKeyboardButton("Bengali 🇧🇩", callback_data="lang_bn")],
            [InlineKeyboardButton("Hindi 🇮🇳", callback_data="lang_hi")],
            [InlineKeyboardButton("Arabic 🇸🇦", callback_data="lang_ar")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.reply_text("Select language:", reply_markup=reply_markup)
    
    elif data.startswith("lang_"):
        lang = data.replace("lang_", "")
        chat_id = update.effective_chat.id
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE settings SET language = ? WHERE group_id = ?", (lang, chat_id))
            conn.commit()
        
        await query.message.reply_text(f"✅ Language set to {lang.upper()}")
        await query.message.delete()
    
    elif data == "captcha":
        # Handle captcha response
        user_id = update.effective_user.id
        expected = context.user_data.get(f'captcha_{user_id}')
        
        if expected:
            # This would need proper handling with user input
            await query.message.reply_text("Please type the answer to the captcha.")
        else:
            await query.message.reply_text("No active captcha found.")

# ==================== CHAT MEMBER HANDLER ====================
async def chat_member_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle chat member updates"""
    result = update.chat_member
    
    # Check if user was restricted/unrestricted
    if result.old_chat_member.status != result.new_chat_member.status:
        if result.new_chat_member.status == ChatMemberStatus.RESTRICTED:
            # User was muted
            pass
        elif result.old_chat_member.status == ChatMemberStatus.RESTRICTED:
            # User was unmuted
            pass

# ==================== ERROR HANDLER ====================
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors"""
    logging.error(f"Update {update} caused error {context.error}")
    
    try:
        if update and update.effective_message:
            await update.effective_message.reply_text(
                "An error occurred. Please try again later."
            )
    except:
        pass

# ==================== MAIN FUNCTION ====================
def main():
    """Main function to run the bot"""
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("rules", rules_command))
    application.add_handler(CommandHandler("setrules", set_rules_command))
    application.add_handler(CommandHandler("welcome", welcome_command))
    application.add_handler(CommandHandler("filter", filter_command))
    application.add_handler(CommandHandler("filters", filters_command))
    application.add_handler(CommandHandler("removefilter", removefilter_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("unban", unban_command))
    application.add_handler(CommandHandler("kick", kick_command))
    application.add_handler(CommandHandler("warn", warn_command))
    application.add_handler(CommandHandler("warnings", warnings_command))
    application.add_handler(CommandHandler("resetwarns", resetwarns_command))
    application.add_handler(CommandHandler("mute", mute_command))
    application.add_handler(CommandHandler("unmute", unmute_command))
    application.add_handler(CommandHandler("pin", pin_command))
    application.add_handler(CommandHandler("unpin", unpin_command))
    application.add_handler(CommandHandler("purge", purge_command))
    application.add_handler(CommandHandler("lock", lock_command))
    application.add_handler(CommandHandler("unlock", unlock_command))
    application.add_handler(CommandHandler("id", id_command))
    application.add_handler(CommandHandler("info", info_command))
    
    # Message handlers
    application.add_handler(MessageHandler(
        filters.StatusUpdate.NEW_CHAT_MEMBERS, handle_new_members
    ))
    application.add_handler(MessageHandler(
        filters.StatusUpdate.LEFT_CHAT_MEMBER, handle_left_members
    ))
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, handle_messages
    ))
    
    # Callback handler
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Chat member handler
    application.add_handler(ChatMemberHandler(chat_member_update, ChatMemberHandler.CHAT_MEMBER))
    
    # Error handler
    application.add_error_handler(error_handler)
    
    # Start bot
    print("🤖 Bot is starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()