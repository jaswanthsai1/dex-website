from flask import Flask, request, jsonify, send_from_directory, render_template_string
from flask_cors import CORS
import sys
import jwt
import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import RemoveFriend_Req_pb2
from byte import Encrypt_ID, encrypt_api
import binascii
import data_pb2
import uid_generator_pb2
import my_pb2
import output_pb2
from datetime import datetime
import json
import time
import urllib3
import warnings
import base64
import os
import httpx
import asyncio
import ssl
import aiohttp
from google.protobuf import json_format

# -----------------------------
# Security Warnings Disable
# -----------------------------
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=UserWarning, message="Unverified HTTPS request")

app = Flask(__name__)
CORS(app)

# -----------------------------
# Configuration
# -----------------------------
PLATFORM_MAP = {
    "3": {"name": "Facebook", "icon": "fab fa-facebook", "color": "#1877F2"},
    "4": {"name": "Guest", "icon": "fas fa-user", "color": "#6c757d"},
    "5": {"name": "VK", "icon": "fab fa-vk", "color": "#4C75A3"},
    "8": {"name": "Google", "icon": "fab fa-google", "color": "#DB4437"},
    "10": {"name": "Apple", "icon": "fab fa-apple", "color": "#000000"},
    "11": {"name": "Twitter/X", "icon": "fab fa-twitter", "color": "#1DA1F2"}
}

REGION_CONFIGS = {
    "ind": {
        "url": "https://client.ind.freefiremobile.com",
        "host": "client.ind.freefiremobile.com",
        "name": "INDIA"
    },
    "us": {
        "url": "https://client.us.freefiremobile.com",
        "host": "client.us.freefiremobile.com",
        "name": "USA/BRAZIL"
    },
    "default": {
        "url": "https://clientbp.ggpolarbear.com",
        "host": "clientbp.common.ggbluefox.com",
        "name": "INTERNATIONAL"
    }
}

# External API URLs
EAT_TOKEN_URL = "https://ticket.kiosgamer.co.id"
JWT_API_URL = "http://raw.sukhdaku.qzz.io/access/token?token={token}"

# Player Info Configuration
MAIN_KEY = base64.b64decode('WWcmdGMlREV1aDYlWmNeOA==')
MAIN_IV = base64.b64decode('Nm95WkRyMjJFM3ljaGpNJQ==')
USERAGENT = "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)"

# -----------------------------
# AES Configuration
# -----------------------------
AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

def encrypt_message(data_bytes):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(data_bytes, AES.block_size))

def encrypt_message_hex(data_bytes):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    encrypted = cipher.encrypt(pad(data_bytes, AES.block_size))
    return binascii.hexlify(encrypted).decode('utf-8')

# -----------------------------
# AES CBC Encryption for Player Info
# -----------------------------
def aes_cbc_encrypt(key: bytes, iv: bytes, plaintext: bytes) -> bytes:
    """AES CBC encryption with PKCS7 padding for player info"""
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_data = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_data)

# -----------------------------
# Region-based URL Configuration
# -----------------------------
def get_base_url(server_name="IND"):
    """Get base URL for a server region"""
    if server_name and server_name.lower() in REGION_CONFIGS:
        return REGION_CONFIGS[server_name.lower()]["url"] + "/"
    return REGION_CONFIGS["default"]["url"] + "/"

def get_server_from_token(token):
    """Extract server region from JWT token"""
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        lock_region = decoded.get("lock_region", "IND")
        return lock_region.upper()
    except:
        return "IND"

# -----------------------------
# Retry Decorator
# -----------------------------
def retry_operation(max_retries=3, delay=1):
    def decorator(func):
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (attempt + 1))
            
            if last_exception:
                return {
                    "success": False,
                    "status": "error",
                    "message": f"All {max_retries} attempts failed",
                    "error": str(last_exception)
                }
            return {
                "success": False,
                "status": "error", 
                "message": f"All {max_retries} attempts failed"
            }
        return wrapper
    return decorator

# -----------------------------
# Token Processing Functions
# -----------------------------
def process_eat_token(eat_token):
    """Convert EAT token to Access Token"""
    try:
        # First get EAT token from kiosgamer
        eat_response = requests.get(EAT_TOKEN_URL, verify=False, timeout=10)
        if eat_response.status_code != 200:
            return None, "Failed to get EAT token"
        
        # Then convert to access token
        access_url = f"https://api-otrss.garena.com/support/callback/?access_token={eat_token}"
        access_response = requests.get(access_url, verify=False, timeout=10)
        
        if access_response.status_code != 200:
            return None, "Failed to convert EAT to Access token"
        
        # Try to extract access token
        try:
            data = access_response.json()
            access_token = data.get('access_token')
            if access_token:
                return access_token, None
        except:
            pass
        
        # Try to extract from text
        text = access_response.text
        if 'access_token' in text:
            # Try to parse access token from response
            import re
            match = re.search(r'access_token["\']?:\s*["\']([^"\']+)["\']', text)
            if match:
                return match.group(1), None
        
        return None, "Could not extract access token from response"
        
    except Exception as e:
        return None, f"EAT token processing error: {str(e)}"

def convert_to_jwt(token, token_type):
    """Convert various token types to JWT"""
    try:
        if token_type == 'token':
            # Already JWT token
            return token, None, None
            
        elif token_type == 'access_token':
            # Convert access token to JWT
            url = JWT_API_URL.format(token=token)
            response = requests.get(url, verify=False, timeout=10)
            
            if response.status_code != 200:
                return None, None, f"Failed to convert access token to JWT: HTTP {response.status_code}"
            
            try:
                data = response.json()
                jwt_token = data.get('token')
                if jwt_token:
                    return jwt_token, data, None
                else:
                    return None, None, "No JWT token in response"
            except:
                # Try to extract from text
                text = response.text
                if 'token' in text:
                    import re
                    match = re.search(r'token["\']?:\s*["\']([^"\']+)["\']', text)
                    if match:
                        return match.group(1), None, None
                return None, None, "Invalid JSON response"
            
        elif token_type == 'eat_token':
            # Process EAT token
            access_token, error = process_eat_token(token)
            if error:
                return None, None, error
            
            # Convert to JWT
            return convert_to_jwt(access_token, 'access_token')
            
        else:
            return None, None, f"Unknown token type: {token_type}"
            
    except requests.exceptions.Timeout:
        return None, None, "Request timeout - server may be down"
    except requests.exceptions.ConnectionError:
        return None, None, "Connection error - check your internet"
    except Exception as e:
        return None, None, f"Token conversion error: {str(e)}"

def resolve_token(token):
    """Ensure token is a JWT, convert if it's an access_token"""
    if not token:
        return None, "Missing token"
    
    try:
        # Check if already a valid JWT
        jwt.decode(token, options={"verify_signature": False})
        return token, None
    except:
        # Not a JWT, try converting from access_token
        jwt_token, _, error = convert_to_jwt(token, 'access_token')
        if error:
            return None, f"Token conversion failed: {error}"
        return jwt_token, None

def extract_user_info(jwt_token):
    """Extract user information from JWT token"""
    try:
        decoded = jwt.decode(jwt_token, options={"verify_signature": False})
        
        your_uid = decoded.get('account_id') or decoded.get('sub') or decoded.get('uid')
        nickname = decoded.get('nickname') or decoded.get('name') or "Unknown"
        region = decoded.get('lock_region') or decoded.get('region') or "IND"
        platform = decoded.get('external_type') or decoded.get('platform') or "4"
        
        # Get region name
        region_key = region.lower()
        region_name = REGION_CONFIGS.get(region_key, REGION_CONFIGS["default"])["name"]
        
        # Get platform name
        platform_name = PLATFORM_MAP.get(str(platform), {"name": f"Platform {platform}"})["name"]
        
        return {
            "success": True,
            "jwt_token": jwt_token,
            "your_uid": str(your_uid) if your_uid else "Unknown",
            "nickname": nickname,
            "region": region.upper(),
            "region_name": region_name,
            "platform": platform,
            "platform_name": platform_name,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Failed to decode JWT: {str(e)}"
        }

# -----------------------------
# Player Info Functions
# -----------------------------
def create_info_protobuf(uid):
    message = uid_generator_pb2.uid_generator()
    message.saturn_ = int(uid)
    message.garena = 1
    return message.SerializeToString()

def get_player_info_sync(target_uid, token, server_name=None):
    """Get player information (synchronous version)"""
    try:
        if not server_name:
            server_name = get_server_from_token(token)
            
        protobuf_data = create_info_protobuf(target_uid)
        encrypted_data = encrypt_message_hex(protobuf_data)
        endpoint = get_base_url(server_name) + "GetPlayerPersonalShow"

        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Authorization': f"Bearer {token}",
            'Content-Type': "application/x-www-form-urlencoded",
            'Expect': "100-continue",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': "OB52"
        }

        response = requests.post(endpoint, data=bytes.fromhex(encrypted_data), headers=headers, verify=False, timeout=10)
        
        if response.status_code != 200:
            return None

        hex_response = response.content.hex()
        binary = bytes.fromhex(hex_response)
        
        info = data_pb2.AccountPersonalShowInfo()
        info.ParseFromString(binary)
        
        return info
    except Exception as e:
        print(f"Error getting player info: {e}")
        return None

async def get_player_info_async(uid: str, token: str):
    """Get player information using async method"""
    try:
        server_name = get_server_from_token(token)
        
        # Create request payload using uid_generator_pb2
        message = uid_generator_pb2.uid_generator()
        message.saturn_ = int(uid)
        message.garena = 1
        
        # Serialize protobuf
        payload = message.SerializeToString()
        
        # Encrypt the payload
        encrypted_data = aes_cbc_encrypt(MAIN_KEY, MAIN_IV, payload)
        
        # Prepare headers
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Expect': "100-continue",
            'Authorization': f"Bearer {token}",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': "OB52"
        }
        
        # Get endpoint URL based on server
        endpoint = get_base_url(server_name) + "GetPlayerPersonalShow"
        
        # Make the API call
        async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
            resp = await client.post(endpoint, data=encrypted_data, headers=headers)
            
            if resp.status_code == 200 and len(resp.content) > 10:
                # Parse the protobuf response using data_pb2
                info = data_pb2.AccountPersonalShowInfo()
                info.ParseFromString(resp.content)
                
                # Convert to dictionary
                data = json_format.MessageToDict(info)
                
                # Add metadata
                data["_metadata"] = {
                    "status": "success",
                    "server": server_name,
                    "uid_requested": uid,
                    "timestamp": datetime.now().isoformat(),
                    "response_size": len(resp.content)
                }
                
                return data
            else:
                return {
                    "success": False,
                    "error": f"HTTP {resp.status_code}",
                    "status_code": resp.status_code,
                    "content_length": len(resp.content)
                }
    
    except ValueError as e:
        return {
            "success": False,
            "error": f"Invalid UID format: {e}",
            "uid": uid
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "type": type(e).__name__
        }

def convert_timestamps_to_dates(data):
    """Recursively convert Unix timestamps to readable dates"""
    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            if any(time_key in key.lower() for time_key in ['time', 'at', 'expire', 'end', 'start', 'create', 'login']):
                if isinstance(value, (str, int)) and (isinstance(value, int) or value.isdigit()):
                    try:
                        timestamp = int(value)
                        if timestamp > 946684800:  # After 2000
                            result[key] = {
                                "timestamp": value,
                                "date": datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S'),
                                "readable": datetime.fromtimestamp(timestamp).strftime('%B %d, %Y at %I:%M:%S %p')
                            }
                        else:
                            result[key] = value
                    except (ValueError, TypeError):
                        result[key] = value
                else:
                    result[key] = convert_timestamps_to_dates(value)
            else:
                result[key] = convert_timestamps_to_dates(value)
        return result
    elif isinstance(data, list):
        return [convert_timestamps_to_dates(item) for item in data]
    else:
        return data

def extract_player_info(info_data):
    """Extract player information from protobuf response"""
    if not info_data:
        return None

    basic_info = info_data.basic_info
    return {
        'uid': basic_info.account_id,
        'nickname': basic_info.nickname,
        'level': basic_info.level,
        'region': basic_info.region,
        'likes': basic_info.liked,
        'release_version': basic_info.release_version,
        'total_matches': getattr(basic_info, 'total_matches', 0),
        'wins': getattr(basic_info, 'wins', 0),
        'rank': getattr(basic_info, 'rank', 0),
        'max_rank': getattr(basic_info, 'max_rank', 0),
        'cs_rank': getattr(basic_info, 'cs_rank', 0),
        'cs_max_rank': getattr(basic_info, 'cs_max_rank', 0)
    }

# -----------------------------
# Authentication API Endpoint
# -----------------------------
@app.route('/api/process-token', methods=['POST', 'OPTIONS'])
def process_token():
    """Process different types of tokens and convert to JWT"""
    try:
        if request.method == 'OPTIONS':
            return jsonify({"success": True}), 200
            
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "No JSON data provided"}), 400
            
        token = data.get('token', '').strip()
        token_type = data.get('token_type', 'token')
        
        if not token:
            return jsonify({
                "success": False,
                "error": "No token provided"
            }), 400
        
        # Convert to JWT
        jwt_token, api_data, error = convert_to_jwt(token, token_type)
        if error:
            return jsonify({
                "success": False,
                "error": error
            }), 400
        
        # Extract user info
        user_info = extract_user_info(jwt_token)
        if not user_info["success"]:
            return jsonify(user_info), 400
        
        # Merge with API data if available
        if api_data:
            # Create a clean combined response
            response_data = user_info.copy()
            for key, value in api_data.items():
                if key not in response_data or value:
                    response_data[key] = value
            return jsonify(response_data)
        
        return jsonify(user_info)
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Server error: {str(e)}"
        }), 500

# -----------------------------
# Get Player Info API
# -----------------------------
@app.route('/api/get-player-info', methods=['GET', 'OPTIONS'])
def get_player_info():
    """Get player information using user's token"""
    try:
        token = request.args.get('token') or request.args.get('access_token')
        target_uid = request.args.get('uid')
        
        # Resolve token (auto-convert access token to JWT)
        token, error = resolve_token(token)
        if error:
            return jsonify({
                "success": False,
                "error": error
            }), 400
        
        if not target_uid:
            return jsonify({
                "success": False,
                "error": "Missing target UID"
            }), 400
        
        # Get player info using synchronous method
        info = get_player_info_sync(target_uid, token)
        
        if info:
            # Extract player info
            player_data = extract_player_info(info)
            
            if player_data:
                # Add timestamp
                player_data["success"] = True
                player_data["timestamp"] = datetime.now().isoformat()
                player_data["message"] = f"Successfully retrieved info for UID: {target_uid}"
                
                return jsonify(player_data)
            else:
                return jsonify({
                    "success": False,
                    "error": "Failed to extract player info"
                }), 400
        else:
            return jsonify({
                "success": False,
                "error": f"Failed to get player info for UID: {target_uid}",
                "status_code": 404
            }), 404
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Server error: {str(e)}"
        }), 500

@app.route('/api/get-player-info-async', methods=['GET', 'OPTIONS'])
async def get_player_info_async_endpoint():
    """Get player information using async method"""
    try:
        token = request.args.get('token') or request.args.get('access_token')
        target_uid = request.args.get('uid')
        
        # Resolve token (auto-convert access token to JWT)
        token, error = resolve_token(token)
        if error:
            return jsonify({
                "success": False,
                "error": error
            }), 400
        
        if not target_uid:
            return jsonify({
                "success": False,
                "error": "Missing target UID"
            }), 400
        
        # Get player info using async method
        result = await get_player_info_async(target_uid, token)
        
        if result.get("success") is not False and "_metadata" in result:
            # Simplify the response for frontend
            simplified_result = {
                "success": True,
                "uid": target_uid,
                "server": result["_metadata"]["server"],
                "timestamp": result["_metadata"]["timestamp"],
                "data": result
            }
            return jsonify(simplified_result)
        else:
            return jsonify({
                "success": False,
                "error": result.get("error", "Unknown error"),
                "uid": target_uid
            }), 400
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Server error: {str(e)}"
        }), 500

# -----------------------------
# Friend Management Functions
# -----------------------------
def decode_author_uid(token):
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        return decoded.get("account_id") or decoded.get("sub")
    except:
        return None

@retry_operation(max_retries=3, delay=1)
def remove_friend_with_retry(author_uid, target_uid, token, server_name=None):
    """Remove friend with retry mechanism"""
    try:
        if not server_name:
            server_name = get_server_from_token(token)
            
        msg = RemoveFriend_Req_pb2.RemoveFriend()
        msg.AuthorUid = int(author_uid)
        msg.TargetUid = int(target_uid)
        encrypted_bytes = encrypt_message(msg.SerializeToString())

        url = get_base_url(server_name) + "RemoveFriend"
        headers = {
            'Authorization': f"Bearer {token}",
            'User-Agent': "Dalvik/2.1.0 (Linux; Android 9)",
            'Content-Type': "application/x-www-form-urlencoded",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': "OB52"
        }

        res = requests.post(url, data=encrypted_bytes, headers=headers, verify=False, timeout=10)
        
        # Check response
        if res.status_code == 200:
            return {
                "success": True,
                "status": "success",
                "message": f"Successfully removed friend {target_uid}",
                "author_uid": author_uid,
                "target_uid": target_uid,
                "server": server_name,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        else:
            return {
                "success": False,
                "status": "failed",
                "message": f"Failed to remove friend: HTTP {res.status_code}",
                "author_uid": author_uid,
                "target_uid": target_uid,
                "server": server_name,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }

    except Exception as e:
        print(f"Remove friend error: {e}")
        raise e

@retry_operation(max_retries=3, delay=1)
def send_friend_request_with_retry(author_uid, target_uid, token, server_name=None):
    """Send friend request with retry mechanism"""
    try:
        if not server_name:
            server_name = get_server_from_token(token)
            
        encrypted_id = Encrypt_ID(target_uid)
        payload = f"08a7c4839f1e10{encrypted_id}1801"
        encrypted_payload = encrypt_api(payload)

        url = get_base_url(server_name) + "RequestAddingFriend"
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB52",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Dalvik/2.1.0 (Linux; Android 9)"
        }

        r = requests.post(url, headers=headers, data=bytes.fromhex(encrypted_payload), verify=False, timeout=10)
        
        # Check response
        if r.status_code == 200:
            return {
                "success": True,
                "status": "success",
                "message": f"Friend request sent to {target_uid}",
                "author_uid": author_uid,
                "target_uid": target_uid,
                "server": server_name,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        else:
            return {
                "success": False,
                "status": "failed",
                "message": f"Failed to send friend request: HTTP {r.status_code}",
                "author_uid": author_uid,
                "target_uid": target_uid,
                "server": server_name,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        
    except Exception as e:
        print(f"Add friend error: {e}")
        raise e

# -----------------------------
# Get Friends List
# -----------------------------
def parse_protobuf_raw(data):
    """Parse raw protobuf binary data into a dictionary."""
    result = {}
    pos = 0
    length = len(data)

    def read_varint():
        nonlocal pos
        value = 0
        shift = 0
        while pos < length:
            byte_val = data[pos]
            pos += 1
            value |= (byte_val & 0x7F) << shift
            if not (byte_val & 0x80):
                break
            shift += 7
        return value

    while pos < length:
        try:
            first_byte = data[pos]
            pos += 1
            field_number = first_byte >> 3
            wire_type = first_byte & 0x07

            if wire_type == 0:
                value = read_varint()
                result.setdefault(field_number, []).append(value)
            elif wire_type == 2:
                chunk_len = read_varint()
                chunk = data[pos:pos + chunk_len]
                pos += chunk_len
                try:
                    string_value = chunk.decode('utf-8')
                    result.setdefault(field_number, []).append(string_value)
                except UnicodeDecodeError:
                    nested = parse_protobuf_raw(chunk)
                    result.setdefault(field_number, []).append(nested)
        except Exception:
            break

    # Unwrap single‑element lists for cleaner output
    for k, v in list(result.items()):
        if isinstance(v, list) and len(v) == 1:
            result[k] = v[0]

    return result

def get_friends_list(token, server_name=None):
    """Get user's friends list (actual implementation using protobuf)."""
    try:
        # Extract user info from the token (needed for the response)
        user_info = extract_user_info(token)
        if not user_info.get("success"):
            return user_info

        # Determine server region if not provided
        if not server_name:
            server_name = get_server_from_token(token)

        # Build the endpoint URL (region‑aware)
        base_url = get_base_url(server_name)
        url = base_url.rstrip('/') + "/GetFriend"

        # Headers (same as other Free Fire endpoints)
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "UnityPlayer/2022.3.47f1",
            "ReleaseVersion": "OB52",
            "X-Unity-Version": "2022.3.47f1",
            "X-GA": "v1 1"
        }

        # Payload (hex string from original function)
        payload = bytes.fromhex('362b36f221ac9ed98b104f7b53c858dc')

        # Make the request
        response = requests.post(url, headers=headers, data=payload, timeout=10)
        raw_data = response.content

        # Try to decode as UTF-8 to detect error messages
        try:
            text = raw_data.decode('utf-8')
            if text.isascii() and ('token' in text.lower() or 'error' in text.lower()):
                return {
                    "success": False,
                    "error": text.strip()
                }
        except:
            pass

        # Parse the protobuf response using the improved parser
        parsed = parse_protobuf_raw(raw_data)

        friends_list = []
        if 1 in parsed and isinstance(parsed[1], list):
            for friend in parsed[1]:
                if not isinstance(friend, dict):
                    continue

                # Extract UID (field 1)
                uid_val = friend.get(1)
                if isinstance(uid_val, list):
                    uid_val = uid_val[0] if uid_val else None
                uid = str(uid_val) if uid_val else None

                # Extract nickname (field 2)
                nickname = None
                if 2 in friend:
                    val = friend[2]
                    if isinstance(val, list):
                        # Look for the first string in the list
                        for v in val:
                            if isinstance(v, str):
                                nickname = v
                                break
                    elif isinstance(val, str):
                        nickname = val
                # If not found, try field 3 (sometimes nickname is there)
                if not nickname and 3 in friend:
                    val = friend[3]
                    if isinstance(val, list):
                        for v in val:
                            if isinstance(v, str):
                                nickname = v
                                break
                    elif isinstance(val, str):
                        nickname = val
                # If still not found, use "Unknown"
                if not nickname:
                    nickname = "Unknown"

                if uid:
                    friends_list.append({
                        "user_id": uid,
                        "nickname": nickname
                    })

        result = {
            "success": True,
            "total_friends": len(friends_list),
            "friends": friends_list,
            "your_uid": user_info.get("your_uid", "Unknown"),
            "nickname": user_info.get("nickname", "Unknown"),
            "region": user_info.get("region", "IND"),
            "region_name": user_info.get("region_name", "INDIA"),
            "platform": user_info.get("platform", "4"),
            "platform_name": user_info.get("platform_name", "Guest"),
            "timestamp": datetime.now().isoformat(),
            "total_size_bytes": len(raw_data)          # optional debugging info
        }
        return result

    except Exception as e:
        return {
            "success": False,
            "error": f"Failed to get friends list: {str(e)}"
        }

# -----------------------------
# API Routes for Frontend
# -----------------------------
@app.route('/adding_friend', methods=['GET', 'OPTIONS'])
def adding_friend():
    """Add friend endpoint"""
    token = request.args.get('token') or request.args.get('access_token')
    friend_uid = request.args.get('friend_uid')
    
    # Resolve token (auto-convert access token to JWT)
    token, error = resolve_token(token)
    if error:
        return jsonify({
            "success": False,
            "error": error
        }), 400
    
    if not friend_uid:
        return jsonify({
            "success": False,
            "error": "Missing friend_uid"
        }), 400
    
    author_uid = decode_author_uid(token)
    if not author_uid:
        return jsonify({
            "success": False,
            "error": "Invalid token"
        }), 400
    
    result = send_friend_request_with_retry(author_uid, friend_uid, token)
    return jsonify(result)

@app.route('/remove_friend', methods=['GET', 'OPTIONS'])
def remove_friend():
    """Remove friend endpoint"""
    token = request.args.get('token') or request.args.get('access_token')
    friend_uid = request.args.get('friend_uid')
    
    # Resolve token (auto-convert access token to JWT)
    token, error = resolve_token(token)
    if error:
        return jsonify({
            "success": False,
            "error": error
        }), 400
    
    if not friend_uid:
        return jsonify({
            "success": False,
            "error": "Missing friend_uid"
        }), 400
    
    author_uid = decode_author_uid(token)
    if not author_uid:
        return jsonify({
            "success": False,
            "error": "Invalid token"
        }), 400
    
    result = remove_friend_with_retry(author_uid, friend_uid, token)
    return jsonify(result)

@app.route('/get_friends_list', methods=['GET', 'OPTIONS'])
def get_friends():
    """Get friends list endpoint"""
    token = request.args.get('token') or request.args.get('access_token')
    
    # Resolve token (auto-convert access token to JWT)
    token, error = resolve_token(token)
    if error:
        return jsonify({
            "success": False,
            "error": error
        }), 400
    
    result = get_friends_list(token)
    return jsonify(result)

# -----------------------------
# CORS Support
# -----------------------------
# CORS is now handled by flask-cors extension
# But we keep this as a secondary check if needed
@app.after_request
def add_cors_headers(response):
    # response.headers.add('Access-Control-Allow-Origin', '*') # Handled by CORS(app)
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# -----------------------------
# Serve HTML & Static Files
# -----------------------------
@app.route('/')
def serve_index():
    """Serve the main HTML file"""
    try:
        return send_from_directory('.', 'index.html')
    except Exception:
        return "index.html not found.", 404

@app.route('/<path:filename>')
def serve_static(filename):
    """Serve static files (CSS, JS, tools, etc.)"""
    # Try serving from root first
    if os.path.exists(filename):
        return send_from_directory('.', filename)
    # If not found, check if it's an HTML file without extension
    if os.path.exists(filename + '.html'):
        return send_from_directory('.', filename + '.html')
    return f"File {filename} not found", 404

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        "status": "healthy", 
        "service": "FreeFire Friend Manager",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0",
        "endpoints": {
            "POST /api/process-token": "Process tokens to JWT",
            "GET /api/get-player-info": "Get player information",
            "GET /api/get-player-info-async": "Get player info (async)",
            "GET /adding_friend": "Send friend request",
            "GET /remove_friend": "Remove friend",
            "GET /get_friends_list": "Get friends list"
        }
    }), 200

# -----------------------------
# Run Server
# -----------------------------
if __name__ == '__main__':
    print("Starting Free Fire Friend Manager...")
    print(f"Server running on: http://localhost:5000")
    print(f"API endpoints:")
    print(f"  POST /api/process-token       - Process tokens")
    print(f"  GET  /api/get-player-info     - Get player info (sync)")
    print(f"  GET  /api/get-player-info-async - Get player info (async)")
    print(f"  GET  /adding_friend           - Add friend")
    print(f"  GET  /remove_friend           - Remove friend")
    print(f"  GET  /get_friends_list        - Get friends list")
    print(f"  GET  /health                  - Health check")
    print("\nMake sure index.html is in the same directory!")
    app.run(host='0.0.0.0', port=30448, debug=True)